"""
Skillgrid — FastAPI + SQLite backend.
Run: uvicorn main:app --reload --port 8000
"""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt
import jwt
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, field_validator
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
    inspect,
    text,
)
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./skillgrid.db")
SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production-please-use-long-random-string")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    avatar_url = Column(String, nullable=True)
    department = Column(String, nullable=True)
    position = Column(String, nullable=True)
    role = Column(String, nullable=False, default="employee")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class Category(Base):
    __tablename__ = "categories"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class Course(Base):
    __tablename__ = "courses"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category_id = Column(String, ForeignKey("categories.id", ondelete="SET NULL"), nullable=True)
    cover_url = Column(String, nullable=True)
    is_published = Column(Boolean, nullable=False, default=False)
    passing_score = Column(Integer, nullable=False, default=70)
    created_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class CourseLesson(Base):
    __tablename__ = "course_lessons"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    course_id = Column(String, ForeignKey("courses.id", ondelete="CASCADE"), nullable=False)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=True)
    video_url = Column(String, nullable=True)
    position = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class CourseEnrollment(Base):
    __tablename__ = "course_enrollments"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    course_id = Column(String, ForeignKey("courses.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    enrolled_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    progress = Column(Integer, nullable=False, default=0)


class LessonProgress(Base):
    __tablename__ = "lesson_progress"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    lesson_id = Column(String, ForeignKey("course_lessons.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    completed = Column(Boolean, nullable=False, default=False)
    completed_at = Column(DateTime, nullable=True)


class Test(Base):
    __tablename__ = "tests"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category_id = Column(String, ForeignKey("categories.id", ondelete="SET NULL"), nullable=True)
    course_id = Column(String, ForeignKey("courses.id", ondelete="SET NULL"), nullable=True)
    duration_minutes = Column(Integer, nullable=False, default=30)
    passing_score = Column(Integer, nullable=False, default=70)
    max_attempts = Column(Integer, nullable=False, default=3)
    is_published = Column(Boolean, nullable=False, default=False)
    created_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class Question(Base):
    __tablename__ = "questions"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    test_id = Column(String, ForeignKey("tests.id", ondelete="CASCADE"), nullable=False)
    question_text = Column(Text, nullable=False)
    question_type = Column(String, nullable=False, default="single")
    points = Column(Integer, nullable=False, default=1)
    position = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class AnswerOption(Base):
    __tablename__ = "answer_options"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    question_id = Column(String, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    answer_text = Column(Text, nullable=False)
    is_correct = Column(Boolean, nullable=False, default=False)
    position = Column(Integer, nullable=False, default=0)


class TestAttempt(Base):
    __tablename__ = "test_attempts"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    test_id = Column(String, ForeignKey("tests.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    score = Column(Float, nullable=True)
    passed = Column(Boolean, nullable=True)
    answers = Column(Text, nullable=False, default="{}")


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action = Column(String, nullable=False)
    entity = Column(String, nullable=True)
    entity_id = Column(String, nullable=True)
    extra_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class FeedAnnouncement(Base):
    __tablename__ = "feed_announcements"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    body = Column(Text, nullable=False)
    tag = Column(String, nullable=False, default="Объявление")
    is_published = Column(Boolean, nullable=False, default=False)
    created_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    published_at = Column(DateTime, nullable=True)


class UserNotification(Base):
    __tablename__ = "user_notifications"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String, nullable=False)
    body = Column(Text, nullable=False)
    tag = Column(String, nullable=True)
    announcement_id = Column(
        String, ForeignKey("feed_announcements.id", ondelete="SET NULL"), nullable=True
    )
    is_read = Column(Boolean, nullable=False, default=False)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class FeedSettings(Base):
    __tablename__ = "feed_settings"
    id = Column(String, primary_key=True, default="default")
    title_template = Column(String, nullable=False, default="Добрый день, {name}")
    page_description = Column(Text, nullable=True)
    layout_json = Column(Text, nullable=False, default="[]")
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)


FEED_SETTINGS_ID = "default"


def _default_feed_layout() -> list[dict]:
    return [
        {
            "id": "hero",
            "type": "hero",
            "enabled": True,
            "config": {
                "badge": "Аттестация",
                "title": "Проверьте компетенции прямо сейчас",
                "body": "Пройдите актуальный тест — результат сохраняется в истории.",
                "button_text": "Начать проверку",
                "link_mode": "auto_test",
                "test_id": None,
                "course_id": None,
                "url": "/tests",
            },
        },
        {
            "id": "stats",
            "type": "stats",
            "enabled": True,
            "config": {
                "label_courses": "Курсов в работе",
                "label_tests": "Тестов пройдено",
                "label_passed": "Успешных попыток",
            },
        },
        {
            "id": "announcements",
            "type": "announcements",
            "enabled": True,
            "config": {"title": "Объявления"},
        },
        {
            "id": "continue_courses",
            "type": "continue_courses",
            "enabled": True,
            "config": {"title": "Продолжить обучение", "max_items": 3},
        },
        {
            "id": "new_courses",
            "type": "new_courses",
            "enabled": True,
            "config": {"title": "Рекомендуемые курсы", "max_items": 4},
        },
        {
            "id": "tests",
            "type": "tests",
            "enabled": True,
            "config": {"title": "Тесты к прохождению", "max_items": 4},
        },
        {
            "id": "recent_activity",
            "type": "recent_activity",
            "enabled": True,
            "config": {"title": "Недавняя активность", "max_items": 5},
        },
    ]


def _get_feed_settings(db: Session) -> FeedSettings:
    row = db.query(FeedSettings).filter(FeedSettings.id == FEED_SETTINGS_ID).first()
    if not row:
        row = FeedSettings(
            id=FEED_SETTINGS_ID,
            title_template="Добрый день, {name}",
            page_description="Проверка компетенций: курсы для обучения, тесты для аттестации",
            layout_json=json.dumps(_default_feed_layout(), ensure_ascii=False),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
    return row


def _feed_layout_out(row: FeedSettings) -> dict:
    try:
        blocks = json.loads(row.layout_json or "[]")
    except json.JSONDecodeError:
        blocks = _default_feed_layout()
    if not isinstance(blocks, list):
        blocks = _default_feed_layout()
    return {
        "title_template": row.title_template,
        "page_description": row.page_description,
        "blocks": blocks,
        "updated_at": dt_iso(row.updated_at),
    }


Base.metadata.create_all(bind=engine)


def ensure_db_schema() -> None:
    """SQLite: добавить колонки, если БД создана до обновления модели."""
    insp = inspect(engine)
    if "courses" in insp.get_table_names():
        cols = {c["name"] for c in insp.get_columns("courses")}
        if "passing_score" not in cols:
            with engine.begin() as conn:
                conn.execute(
                    text("ALTER TABLE courses ADD COLUMN passing_score INTEGER NOT NULL DEFAULT 70")
                )


ensure_db_schema()

app = FastAPI(title="Skillgrid API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174",
    ],
    # Любой localhost-порт (Vite часто переключается, если 5173 занят)
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
security = HTTPBearer()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())


def create_token(user_id: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": user_id, "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> str:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_user(
    creds: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
) -> User:
    user_id = decode_token(creds.credentials)
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def dt_iso(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def audit(
    db: Session,
    user_id: str,
    action: str,
    entity: str | None = None,
    entity_id: str | None = None,
    metadata: dict | None = None,
):
    log = AuditLog(
        user_id=user_id,
        action=action,
        entity=entity,
        entity_id=entity_id,
        extra_json=json.dumps(metadata) if metadata else None,
    )
    db.add(log)
    db.commit()


def run_startup_seed():
    from seed_data import run_seed

    db = SessionLocal()
    try:
        run_seed(db)
    finally:
        db.close()


run_startup_seed()


class RegisterIn(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None

    @field_validator("password")
    @classmethod
    def strong_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Минимум 8 символов")
        if not any(c.isupper() for c in v):
            raise ValueError("Нужна хотя бы одна заглавная буква")
        if not any(c.isdigit() for c in v):
            raise ValueError("Нужна хотя бы одна цифра")
        return v


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    department: Optional[str] = None
    position: Optional[str] = None


class CategoryIn(BaseModel):
    name: str
    description: Optional[str] = None


class CourseIn(BaseModel):
    title: str
    description: Optional[str] = None
    category_id: Optional[str] = None
    cover_url: Optional[str] = None
    passing_score: int = 70


class CourseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category_id: Optional[str] = None
    cover_url: Optional[str] = None
    is_published: Optional[bool] = None
    passing_score: Optional[int] = None


class LessonIn(BaseModel):
    title: str
    content: Optional[str] = None
    video_url: Optional[str] = None
    position: int = 0


class LessonUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    video_url: Optional[str] = None
    position: Optional[int] = None


class TestIn(BaseModel):
    title: str
    description: Optional[str] = None
    category_id: Optional[str] = None
    course_id: Optional[str] = None
    duration_minutes: int = 30
    passing_score: int = 70
    max_attempts: int = 3


class TestUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category_id: Optional[str] = None
    course_id: Optional[str] = None
    duration_minutes: Optional[int] = None
    passing_score: Optional[int] = None
    max_attempts: Optional[int] = None
    is_published: Optional[bool] = None


class QuestionIn(BaseModel):
    question_text: str
    question_type: str = "single"
    points: int = 1
    position: int = 0
    answer_options: list[dict] = []


class QuestionUpdate(BaseModel):
    question_text: Optional[str] = None
    question_type: Optional[str] = None
    points: Optional[int] = None
    position: Optional[int] = None
    answer_options: Optional[list[dict]] = None


class AttemptIn(BaseModel):
    answers: dict
    score: float
    passed: bool


class AnnouncementIn(BaseModel):
    title: str
    body: str
    tag: str = "Объявление"


class AnnouncementUpdate(BaseModel):
    title: Optional[str] = None
    body: Optional[str] = None
    tag: Optional[str] = None
    is_published: Optional[bool] = None


class FeedLayoutUpdate(BaseModel):
    title_template: Optional[str] = None
    page_description: Optional[str] = None
    blocks: Optional[list[dict]] = None


def _user_out(u: User) -> dict:
    return {
        "id": u.id,
        "email": u.email,
        "full_name": u.full_name,
        "avatar_url": u.avatar_url,
        "department": u.department,
        "position": u.position,
        "role": u.role,
        "created_at": dt_iso(u.created_at),
        "updated_at": dt_iso(u.updated_at),
    }


@app.post("/auth/register", status_code=201)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(400, "Email уже занят")
    user = User(
        email=data.email,
        password_hash=hash_password(data.password),
        full_name=data.full_name or data.email,
        role="employee",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_token(user.id), "user": _user_out(user)}


@app.post("/auth/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Неверный email или пароль")
    return {"access_token": create_token(user.id), "user": _user_out(user)}


@app.get("/auth/me")
def me(user: User = Depends(get_current_user)):
    return _user_out(user)


@app.patch("/profile")
def update_profile(
    data: ProfileUpdate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if data.full_name is not None:
        user.full_name = data.full_name
    if data.department is not None:
        user.department = data.department or None
    if data.position is not None:
        user.position = data.position or None
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    return _user_out(user)


@app.get("/categories")
def list_categories(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    cats = db.query(Category).order_by(Category.created_at).all()
    return [
        {"id": c.id, "name": c.name, "description": c.description, "created_at": dt_iso(c.created_at)}
        for c in cats
    ]


@app.post("/categories", status_code=201)
def create_category(data: CategoryIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    cat = Category(name=data.name, description=data.description)
    db.add(cat)
    db.commit()
    db.refresh(cat)
    audit(db, admin.id, "create_category", "category", cat.id)
    return {"id": cat.id, "name": cat.name, "description": cat.description, "created_at": dt_iso(cat.created_at)}


@app.delete("/categories/{cat_id}", status_code=204)
def delete_category(cat_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(404, "Категория не найдена")
    db.delete(cat)
    db.commit()


def _get_final_test(db: Session, course_id: str) -> Test | None:
    return (
        db.query(Test)
        .filter(Test.course_id == course_id, Test.is_published == True)
        .order_by(Test.created_at)
        .first()
    )


def _lessons_progress(db: Session, course_id: str, user_id: str) -> tuple[int, int, bool]:
    lesson_ids = [
        l.id
        for l in db.query(CourseLesson)
        .filter(CourseLesson.course_id == course_id)
        .order_by(CourseLesson.position)
        .all()
    ]
    total = len(lesson_ids)
    if total == 0:
        return 0, 0, True
    done = (
        db.query(LessonProgress)
        .filter(
            LessonProgress.lesson_id.in_(lesson_ids),
            LessonProgress.user_id == user_id,
            LessonProgress.completed == True,
        )
        .count()
    )
    return done, total, done >= total


def _final_test_passed(db: Session, test_id: str, user_id: str, threshold: int) -> bool:
    return (
        db.query(TestAttempt)
        .filter(
            TestAttempt.test_id == test_id,
            TestAttempt.user_id == user_id,
            TestAttempt.passed == True,
            TestAttempt.score >= threshold,
        )
        .first()
        is not None
    )


def _compute_course_progress(
    db: Session, course: Course, user_id: str
) -> tuple[int, bool, bool, bool]:
    """progress%, all_lessons_done, final_test_passed, course_completed."""
    done, total, all_lessons = _lessons_progress(db, course.id, user_id)
    final_test = _get_final_test(db, course.id)
    threshold = course.passing_score or 70

    if not final_test:
        progress = 100 if all_lessons else (int((done / total) * 100) if total else 0)
        return progress, all_lessons, False, all_lessons

    lessons_part = int((done / total) * 70) if total else 70
    test_passed = _final_test_passed(db, final_test.id, user_id, threshold)
    test_part = 30 if test_passed else 0
    progress = min(100, lessons_part + test_part)
    completed = all_lessons and test_passed
    return progress, all_lessons, test_passed, completed


def _sync_enrollment_progress(db: Session, course_id: str, user_id: str) -> None:
    course = db.query(Course).filter(Course.id == course_id).first()
    enrollment = (
        db.query(CourseEnrollment)
        .filter(CourseEnrollment.course_id == course_id, CourseEnrollment.user_id == user_id)
        .first()
    )
    if not course or not enrollment:
        return
    progress, _, _, completed = _compute_course_progress(db, course, user_id)
    enrollment.progress = progress
    enrollment.completed_at = datetime.now(timezone.utc) if completed else None
    db.commit()


def _course_out(c: Course, db: Session, user_id: str | None = None) -> dict:
    lessons = (
        db.query(CourseLesson).filter(CourseLesson.course_id == c.id).order_by(CourseLesson.position).all()
    )
    enrollment = None
    if user_id:
        enrollment = (
            db.query(CourseEnrollment)
            .filter(CourseEnrollment.course_id == c.id, CourseEnrollment.user_id == user_id)
            .first()
        )

    final_test = _get_final_test(db, c.id)
    done, total, all_lessons = (0, len(lessons), False)
    test_passed = False
    course_completed = False
    progress = enrollment.progress if enrollment else 0

    if user_id:
        done, total, all_lessons = _lessons_progress(db, c.id, user_id)
    if user_id and enrollment:
        progress, all_lessons, test_passed, course_completed = _compute_course_progress(db, c, user_id)
        if enrollment.progress != progress or (
            course_completed and not enrollment.completed_at
        ) or (not course_completed and enrollment.completed_at):
            enrollment.progress = progress
            enrollment.completed_at = datetime.now(timezone.utc) if course_completed else None
            db.commit()

    can_take_final = bool(final_test and all_lessons)

    return {
        "id": c.id,
        "title": c.title,
        "description": c.description,
        "category_id": c.category_id,
        "cover_url": c.cover_url,
        "is_published": c.is_published,
        "passing_score": c.passing_score or 70,
        "created_by": c.created_by,
        "created_at": dt_iso(c.created_at),
        "updated_at": dt_iso(c.updated_at),
        "lesson_count": len(lessons),
        "enrolled": enrollment is not None,
        "progress": progress,
        "final_test_id": final_test.id if final_test else None,
        "final_test_title": final_test.title if final_test else None,
        "lessons_completed": done,
        "lessons_total": total,
        "all_lessons_completed": all_lessons,
        "can_take_final_test": can_take_final,
        "final_test_passed": test_passed,
        "course_completed": course_completed,
    }


@app.get("/courses")
def list_courses(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(Course)
    if user.role != "admin":
        query = query.filter(Course.is_published == True)
    courses = query.order_by(Course.created_at.desc()).all()
    return [_course_out(c, db, user.id) for c in courses]


@app.get("/courses/{course_id}")
def get_course(course_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(404, "Курс не найден")
    if not course.is_published and user.role != "admin":
        raise HTTPException(403, "Нет доступа")
    return _course_out(course, db, user.id)


@app.post("/courses", status_code=201)
def create_course(data: CourseIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    course = Course(
        title=data.title,
        description=data.description,
        category_id=data.category_id,
        cover_url=data.cover_url,
        passing_score=data.passing_score,
        created_by=admin.id,
    )
    db.add(course)
    db.commit()
    db.refresh(course)
    audit(db, admin.id, "create_course", "course", course.id)
    return _course_out(course, db)


@app.patch("/courses/{course_id}")
def update_course(
    course_id: str,
    data: CourseUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(404, "Курс не найден")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(course, field, val)
    course.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(course)
    audit(db, admin.id, "update_course", "course", course_id)
    return _course_out(course, db)


@app.delete("/courses/{course_id}", status_code=204)
def delete_course(course_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(404, "Курс не найден")
    db.delete(course)
    db.commit()


def _lesson_out(l: CourseLesson, db: Session, user_id: str | None = None) -> dict:
    completed = False
    if user_id:
        lp = (
            db.query(LessonProgress)
            .filter(LessonProgress.lesson_id == l.id, LessonProgress.user_id == user_id)
            .first()
        )
        completed = bool(lp and lp.completed)
    return {
        "id": l.id,
        "course_id": l.course_id,
        "title": l.title,
        "content": l.content,
        "video_url": l.video_url,
        "position": l.position,
        "created_at": dt_iso(l.created_at),
        "completed": completed,
    }


@app.get("/courses/{course_id}/lessons")
def list_lessons(course_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(404, "Курс не найден")
    if not course.is_published and user.role != "admin":
        raise HTTPException(403, "Нет доступа")
    lessons = (
        db.query(CourseLesson)
        .filter(CourseLesson.course_id == course_id)
        .order_by(CourseLesson.position)
        .all()
    )
    return [_lesson_out(l, db, user.id) for l in lessons]


@app.post("/courses/{course_id}/lessons", status_code=201)
def create_lesson(
    course_id: str,
    data: LessonIn,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    lesson = CourseLesson(
        course_id=course_id,
        title=data.title,
        content=data.content,
        video_url=data.video_url,
        position=data.position,
    )
    db.add(lesson)
    db.commit()
    db.refresh(lesson)
    return _lesson_out(lesson, db)


@app.patch("/courses/{course_id}/lessons/{lesson_id}")
def update_lesson(
    course_id: str,
    lesson_id: str,
    data: LessonUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    lesson = (
        db.query(CourseLesson)
        .filter(CourseLesson.id == lesson_id, CourseLesson.course_id == course_id)
        .first()
    )
    if not lesson:
        raise HTTPException(404, "Урок не найден")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(lesson, field, val)
    db.commit()
    db.refresh(lesson)
    return _lesson_out(lesson, db)


@app.delete("/courses/{course_id}/lessons/{lesson_id}", status_code=204)
def delete_lesson(
    course_id: str,
    lesson_id: str,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    lesson = (
        db.query(CourseLesson)
        .filter(CourseLesson.id == lesson_id, CourseLesson.course_id == course_id)
        .first()
    )
    if not lesson:
        raise HTTPException(404, "Урок не найден")
    db.delete(lesson)
    db.commit()


@app.post("/courses/{course_id}/enroll", status_code=201)
def enroll(course_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    existing = (
        db.query(CourseEnrollment)
        .filter(CourseEnrollment.course_id == course_id, CourseEnrollment.user_id == user.id)
        .first()
    )
    if existing:
        return {"id": existing.id, "progress": existing.progress}
    enrollment = CourseEnrollment(course_id=course_id, user_id=user.id)
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return {"id": enrollment.id, "progress": 0}


@app.post("/courses/{course_id}/lessons/{lesson_id}/complete")
def complete_lesson(
    course_id: str,
    lesson_id: str,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    lp = (
        db.query(LessonProgress)
        .filter(LessonProgress.lesson_id == lesson_id, LessonProgress.user_id == user.id)
        .first()
    )
    if not lp:
        lp = LessonProgress(lesson_id=lesson_id, user_id=user.id)
        db.add(lp)
    lp.completed = True
    lp.completed_at = datetime.now(timezone.utc)
    db.commit()
    _sync_enrollment_progress(db, course_id, user.id)
    return {"completed": True}


@app.get("/my/courses")
def my_courses(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    enrollments = db.query(CourseEnrollment).filter(CourseEnrollment.user_id == user.id).all()
    result = []
    for e in enrollments:
        course = db.query(Course).filter(Course.id == e.course_id).first()
        if course:
            result.append(_course_out(course, db, user.id))
    return result


def _test_user_status(
    db: Session, test_id: str, user_id: str, passing_score: int, max_attempts: int
) -> dict:
    attempts = (
        db.query(TestAttempt)
        .filter(TestAttempt.test_id == test_id, TestAttempt.user_id == user_id)
        .order_by(TestAttempt.completed_at.desc())
        .all()
    )
    completed = [a for a in attempts if a.completed_at is not None]
    best = max((float(a.score) for a in completed if a.score is not None), default=None)
    passed = any(
        a.passed and a.score is not None and float(a.score) >= passing_score for a in completed
    )
    used = len(completed)
    unlimited = max_attempts <= 0
    can_attempt = unlimited or used < max_attempts
    attempts_left = (max_attempts - used) if max_attempts > 0 else None
    return {
        "question_count": db.query(Question).filter(Question.test_id == test_id).count(),
        "user_passed": passed,
        "user_best_score": best,
        "user_attempts": used,
        "user_attempts_left": attempts_left,
        "can_attempt": can_attempt,
    }


def _test_out(t: Test, db: Session | None = None, user_id: str | None = None) -> dict:
    base = {
        "id": t.id,
        "title": t.title,
        "description": t.description,
        "category_id": t.category_id,
        "course_id": t.course_id,
        "duration_minutes": t.duration_minutes,
        "passing_score": t.passing_score,
        "max_attempts": t.max_attempts,
        "is_published": t.is_published,
        "created_by": t.created_by,
        "created_at": dt_iso(t.created_at),
        "updated_at": dt_iso(t.updated_at),
    }
    if db is not None:
        status = (
            _test_user_status(db, t.id, user_id, t.passing_score, t.max_attempts)
            if user_id
            else {
                "question_count": db.query(Question).filter(Question.test_id == t.id).count(),
                "user_passed": False,
                "user_best_score": None,
                "user_attempts": 0,
                "user_attempts_left": None,
                "can_attempt": True,
            }
        )
        base.update(status)
    return base


def _calculate_score(db: Session, test_id: str, answers: dict) -> float:
    questions = (
        db.query(Question).filter(Question.test_id == test_id).order_by(Question.position).all()
    )
    earned = 0
    total = 0
    for q in questions:
        total += q.points
        opts = (
            db.query(AnswerOption)
            .filter(AnswerOption.question_id == q.id)
            .order_by(AnswerOption.position)
            .all()
        )
        a = answers.get(q.id)
        if q.question_type in ("single", "true_false"):
            correct = next((o.id for o in opts if o.is_correct), None)
            if a == correct:
                earned += q.points
        elif q.question_type == "multiple":
            correct = sorted(o.id for o in opts if o.is_correct)
            given = sorted(a) if isinstance(a, list) else []
            if correct == given:
                earned += q.points
        elif q.question_type == "text":
            expected = next(
                (o.answer_text.strip().lower() for o in opts if o.is_correct),
                None,
            )
            if expected and isinstance(a, str) and a.strip().lower() == expected:
                earned += q.points
        elif q.question_type == "drag_drop":
            correct_order = [o.id for o in sorted(opts, key=lambda x: x.position)]
            given = a if isinstance(a, list) else []
            if correct_order == given:
                earned += q.points
    return (earned / total * 100) if total else 0.0


@app.get("/tests")
def list_tests(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(Test)
    if user.role != "admin":
        query = query.filter(Test.is_published == True)
    tests = query.order_by(Test.created_at.desc()).all()
    return [_test_out(t, db, user.id) for t in tests]


@app.get("/tests/{test_id}")
def get_test(test_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(404, "Тест не найден")
    if not test.is_published and user.role != "admin":
        raise HTTPException(403, "Нет доступа")
    hide_correct = user.role != "admin"
    questions = db.query(Question).filter(Question.test_id == test_id).order_by(Question.position).all()
    qs_out = []
    for q in questions:
        opts = (
            db.query(AnswerOption)
            .filter(AnswerOption.question_id == q.id)
            .order_by(AnswerOption.position)
            .all()
        )
        qs_out.append(
            {
                "id": q.id,
                "question_text": q.question_text,
                "question_type": q.question_type,
                "points": q.points,
                "position": q.position,
                "answer_options": [
                    {
                        "id": o.id,
                        "answer_text": o.answer_text,
                        "is_correct": False if hide_correct else o.is_correct,
                        "position": o.position,
                    }
                    for o in opts
                ],
            }
        )
    return {**_test_out(test, db, user.id), "questions": qs_out}


@app.post("/tests", status_code=201)
def create_test(data: TestIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    test = Test(
        title=data.title,
        description=data.description,
        category_id=data.category_id,
        course_id=data.course_id,
        duration_minutes=data.duration_minutes,
        passing_score=data.passing_score,
        max_attempts=data.max_attempts,
        created_by=admin.id,
    )
    db.add(test)
    db.commit()
    db.refresh(test)
    audit(db, admin.id, "create_test", "test", test.id)
    return _test_out(test, db)


@app.patch("/tests/{test_id}")
def update_test(
    test_id: str,
    data: TestUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(404, "Тест не найден")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(test, field, val)
    test.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(test)
    audit(db, admin.id, "update_test", "test", test_id, {"is_published": test.is_published})
    return _test_out(test, db)


@app.delete("/tests/{test_id}", status_code=204)
def delete_test(test_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(404, "Тест не найден")
    title = test.title
    db.delete(test)
    db.commit()
    audit(db, admin.id, "delete_test", "test", test_id, {"title": title})


@app.post("/tests/{test_id}/questions", status_code=201)
def add_question(
    test_id: str,
    data: QuestionIn,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    q = Question(
        test_id=test_id,
        question_text=data.question_text,
        question_type=data.question_type,
        points=data.points,
        position=data.position,
    )
    db.add(q)
    db.flush()
    for opt in data.answer_options:
        db.add(
            AnswerOption(
                question_id=q.id,
                answer_text=opt.get("answer_text", ""),
                is_correct=opt.get("is_correct", False),
                position=opt.get("position", 0),
            )
        )
    db.commit()
    db.refresh(q)
    opts = db.query(AnswerOption).filter(AnswerOption.question_id == q.id).all()
    return {
        "id": q.id,
        "question_text": q.question_text,
        "question_type": q.question_type,
        "points": q.points,
        "position": q.position,
        "answer_options": [
            {
                "id": o.id,
                "answer_text": o.answer_text,
                "is_correct": o.is_correct,
                "position": o.position,
            }
            for o in opts
        ],
    }


@app.patch("/tests/{test_id}/questions/{q_id}")
def update_question(
    test_id: str,
    q_id: str,
    data: QuestionUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    q = db.query(Question).filter(Question.id == q_id, Question.test_id == test_id).first()
    if not q:
        raise HTTPException(404, "Вопрос не найден")
    for field, val in data.model_dump(exclude_none=True, exclude={"answer_options"}).items():
        setattr(q, field, val)
    if data.answer_options is not None:
        db.query(AnswerOption).filter(AnswerOption.question_id == q_id).delete()
        for opt in data.answer_options:
            db.add(
                AnswerOption(
                    question_id=q_id,
                    answer_text=opt.get("answer_text", ""),
                    is_correct=opt.get("is_correct", False),
                    position=opt.get("position", 0),
                )
            )
    db.commit()
    db.refresh(q)
    opts = db.query(AnswerOption).filter(AnswerOption.question_id == q_id).all()
    return {
        "id": q.id,
        "question_text": q.question_text,
        "question_type": q.question_type,
        "points": q.points,
        "position": q.position,
        "answer_options": [
            {
                "id": o.id,
                "answer_text": o.answer_text,
                "is_correct": o.is_correct,
                "position": o.position,
            }
            for o in opts
        ],
    }


@app.delete("/tests/{test_id}/questions/{q_id}", status_code=204)
def delete_question(
    test_id: str,
    q_id: str,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    q = db.query(Question).filter(Question.id == q_id, Question.test_id == test_id).first()
    if not q:
        raise HTTPException(404, "Вопрос не найден")
    db.delete(q)
    db.commit()


@app.post("/tests/{test_id}/attempts", status_code=201)
def submit_attempt(
    test_id: str,
    data: AttemptIn,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(404, "Тест не найден")
    if not test.is_published and user.role != "admin":
        raise HTTPException(403, "Нет доступа")

    status = _test_user_status(db, test_id, user.id, test.passing_score, test.max_attempts)
    if user.role != "admin" and not status["can_attempt"]:
        left = status["user_attempts_left"]
        raise HTTPException(
            403,
            f"Исчерпан лимит попыток ({test.max_attempts}). Осталось: {left or 0}",
        )

    final_score = _calculate_score(db, test_id, data.answers)
    passed = final_score >= test.passing_score

    attempt = TestAttempt(
        test_id=test_id,
        user_id=user.id,
        completed_at=datetime.now(timezone.utc),
        score=final_score,
        passed=passed,
        answers=json.dumps(data.answers),
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)
    audit(
        db,
        user.id,
        "submit_attempt",
        "test_attempt",
        attempt.id,
        {"score": final_score, "passed": passed},
    )

    if test and test.course_id and passed:
        course = db.query(Course).filter(Course.id == test.course_id).first()
        threshold = (course.passing_score if course else None) or test.passing_score
        if final_score >= threshold:
            _sync_enrollment_progress(db, test.course_id, user.id)

    return {
        "id": attempt.id,
        "test_id": attempt.test_id,
        "score": attempt.score,
        "passed": attempt.passed,
        "completed_at": dt_iso(attempt.completed_at),
        "course_id": test.course_id if test else None,
    }


@app.get("/my/attempts")
def my_attempts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    attempts = (
        db.query(TestAttempt)
        .filter(TestAttempt.user_id == user.id)
        .order_by(TestAttempt.started_at.desc())
        .all()
    )
    result = []
    for a in attempts:
        test = db.query(Test).filter(Test.id == a.test_id).first()
        result.append(
            {
                "id": a.id,
                "test_id": a.test_id,
                "test_title": test.title if test else None,
                "score": a.score,
                "passed": a.passed,
                "started_at": dt_iso(a.started_at),
                "completed_at": dt_iso(a.completed_at),
            }
        )
    return result


@app.get("/admin/analytics")
def admin_analytics(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    from collections import defaultdict

    attempts = (
        db.query(TestAttempt)
        .filter(TestAttempt.completed_at.isnot(None), TestAttempt.score.isnot(None))
        .all()
    )

    monthly: dict[str, list[float]] = defaultdict(list)
    for a in attempts:
        if a.completed_at:
            key = a.completed_at.strftime("%Y-%m")
            monthly[key].append(float(a.score))

    month_names = {
        "01": "Янв",
        "02": "Фев",
        "03": "Мар",
        "04": "Апр",
        "05": "Май",
        "06": "Июн",
        "07": "Июл",
        "08": "Авг",
        "09": "Сен",
        "10": "Окт",
        "11": "Ноя",
        "12": "Дек",
    }
    sorted_months = sorted(monthly.keys())[-6:]
    score_by_month = [
        {
            "month": month_names.get(m.split("-")[1], m),
            "avg_score": round(sum(monthly[m]) / len(monthly[m]), 1),
            "attempts": len(monthly[m]),
        }
        for m in sorted_months
    ]

    dept_stats: dict[str, dict] = defaultdict(lambda: {"attempts": 0, "passed": 0})
    for a in attempts:
        u = db.query(User).filter(User.id == a.user_id).first()
        dept = (u.department if u and u.department else None) or "Без отдела"
        dept_stats[dept]["attempts"] += 1
        if a.passed:
            dept_stats[dept]["passed"] += 1

    by_department = []
    total_attempts = sum(d["attempts"] for d in dept_stats.values()) or 1
    for name, st in sorted(dept_stats.items(), key=lambda x: -x[1]["attempts"]):
        by_department.append(
            {
                "name": name,
                "attempts": st["attempts"],
                "share": round(st["attempts"] / total_attempts * 100, 1),
                "pass_rate": round(st["passed"] / st["attempts"] * 100, 1) if st["attempts"] else 0,
            }
        )

    now = datetime.now(timezone.utc)
    daily = []
    for i in range(6, -1, -1):
        day = (now - timedelta(days=i)).date()
        count = sum(
            1
            for a in attempts
            if a.completed_at and a.completed_at.date() == day
        )
        labels = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        daily.append({"name": labels[day.weekday()], "count": count})

    return {
        "score_by_month": score_by_month,
        "by_department": by_department,
        "activity_by_day": daily,
    }


@app.get("/admin/stats")
def admin_stats(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    attempts = db.query(TestAttempt).filter(TestAttempt.completed_at.isnot(None)).all()
    avg = sum(a.score or 0 for a in attempts) / len(attempts) if attempts else 0
    passed = sum(1 for a in attempts if a.passed)
    pass_rate = (passed / len(attempts) * 100) if attempts else 0
    return {
        "users": db.query(User).count(),
        "active_tests": db.query(Test).filter(Test.is_published == True).count(),
        "active_courses": db.query(Course).filter(Course.is_published == True).count(),
        "avg_score": round(avg, 1),
        "pass_rate": round(pass_rate, 1),
        "total_attempts": len(attempts),
    }


@app.get("/admin/users")
def admin_users(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return [_user_out(u) for u in users]


@app.patch("/admin/users/{user_id}/role")
def set_user_role(
    user_id: str,
    body: dict,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    role = body.get("role")
    if role not in ("admin", "employee"):
        raise HTTPException(400, "Неверная роль")
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(404, "Пользователь не найден")
    u.role = role
    db.commit()
    audit(db, admin.id, "set_role", "user", user_id, {"role": role})
    return _user_out(u)


@app.get("/admin/audit")
def admin_audit(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    logs = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(200).all()
    return [
        {
            "id": l.id,
            "user_id": l.user_id,
            "action": l.action,
            "entity": l.entity,
            "entity_id": l.entity_id,
            "metadata": json.loads(l.extra_json) if l.extra_json else None,
            "created_at": dt_iso(l.created_at),
        }
        for l in logs
    ]


@app.get("/feed")
def feed(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Лента: продолжить обучение, новинки, тесты, активность."""
    enrollments = (
        db.query(CourseEnrollment)
        .filter(CourseEnrollment.user_id == user.id, CourseEnrollment.progress < 100)
        .all()
    )
    continue_courses = []
    for e in enrollments[:4]:
        c = db.query(Course).filter(Course.id == e.course_id, Course.is_published == True).first()
        if c:
            continue_courses.append(_course_out(c, db, user.id))

    enrolled_ids = {e.course_id for e in db.query(CourseEnrollment).filter(CourseEnrollment.user_id == user.id).all()}
    new_courses_q = db.query(Course).filter(Course.is_published == True)
    if user.role != "admin":
        new_courses_q = new_courses_q.filter(Course.is_published == True)
    new_courses = []
    for c in new_courses_q.order_by(Course.created_at.desc()).limit(12).all():
        if c.id not in enrolled_ids:
            new_courses.append(_course_out(c, db, user.id))
        if len(new_courses) >= 4:
            break

    tests_due = [
        _test_out(t, db, user.id)
        for t in db.query(Test)
        .filter(Test.is_published == True)
        .order_by(Test.created_at.desc())
        .limit(4)
        .all()
    ]

    attempts = (
        db.query(TestAttempt)
        .filter(TestAttempt.user_id == user.id, TestAttempt.completed_at.isnot(None))
        .order_by(TestAttempt.completed_at.desc())
        .limit(5)
        .all()
    )
    recent_attempts = []
    for a in attempts:
        t = db.query(Test).filter(Test.id == a.test_id).first()
        recent_attempts.append(
            {
                "id": a.id,
                "test_id": a.test_id,
                "test_title": t.title if t else None,
                "score": a.score,
                "passed": a.passed,
                "completed_at": dt_iso(a.completed_at),
            }
        )

    my_enrolled = db.query(CourseEnrollment).filter(CourseEnrollment.user_id == user.id).count()
    completed_tests = (
        db.query(TestAttempt)
        .filter(TestAttempt.user_id == user.id, TestAttempt.completed_at.isnot(None))
        .count()
    )
    passed_tests = (
        db.query(TestAttempt)
        .filter(TestAttempt.user_id == user.id, TestAttempt.passed == True)
        .count()
    )

    featured_test = tests_due[0] if tests_due else None
    settings = _get_feed_settings(db)
    name = user.full_name or user.email.split("@")[0]

    return {
        "layout": _feed_layout_out(settings),
        "greeting": settings.title_template.replace("{name}", name),
        "continue_courses": continue_courses,
        "new_courses": new_courses,
        "tests_due": tests_due,
        "featured_test_id": featured_test["id"] if featured_test else None,
        "featured_test_title": featured_test["title"] if featured_test else None,
        "recent_attempts": recent_attempts,
        "stats": {
            "courses_enrolled": my_enrolled,
            "tests_completed": completed_tests,
            "tests_passed": passed_tests,
        },
        "highlights": _feed_highlights(db, user.id),
    }


@app.get("/admin/feed/layout")
def get_feed_layout(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return _feed_layout_out(_get_feed_settings(db))


@app.put("/admin/feed/layout")
def update_feed_layout(
    data: FeedLayoutUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    row = _get_feed_settings(db)
    if data.title_template is not None:
        row.title_template = data.title_template
    if data.page_description is not None:
        row.page_description = data.page_description
    if data.blocks is not None:
        row.layout_json = json.dumps(data.blocks, ensure_ascii=False)
    row.updated_at = datetime.now(timezone.utc)
    row.updated_by = admin.id
    db.commit()
    db.refresh(row)
    audit(db, admin.id, "update_feed_layout", "feed_settings", row.id)
    return _feed_layout_out(row)


def _announcement_out(a: FeedAnnouncement, db: Session, user_id: str | None = None) -> dict:
    is_read = True
    if user_id:
        n = (
            db.query(UserNotification)
            .filter(
                UserNotification.user_id == user_id,
                UserNotification.announcement_id == a.id,
            )
            .first()
        )
        if n:
            is_read = n.is_read
    return {
        "id": a.id,
        "title": a.title,
        "body": a.body,
        "tag": a.tag,
        "is_published": a.is_published,
        "published_at": dt_iso(a.published_at),
        "created_at": dt_iso(a.created_at),
        "updated_at": dt_iso(a.updated_at),
        "is_read": is_read,
    }


def _feed_highlights(db: Session, user_id: str) -> list[dict]:
    rows = (
        db.query(FeedAnnouncement)
        .filter(FeedAnnouncement.is_published == True)
        .order_by(FeedAnnouncement.published_at.desc())
        .limit(20)
        .all()
    )
    return [_announcement_out(a, db, user_id) for a in rows]


def _notification_out(n: UserNotification) -> dict:
    return {
        "id": n.id,
        "title": n.title,
        "body": n.body,
        "tag": n.tag,
        "announcement_id": n.announcement_id,
        "is_read": n.is_read,
        "read_at": dt_iso(n.read_at),
        "created_at": dt_iso(n.created_at),
    }


def _dispatch_announcement_notifications(db: Session, announcement: FeedAnnouncement) -> int:
    """Создать уведомления всем пользователям. Возвращает число созданных."""
    users = db.query(User).all()
    count = 0
    for u in users:
        db.add(
            UserNotification(
                user_id=u.id,
                title=announcement.title,
                body=announcement.body,
                tag=announcement.tag,
                announcement_id=announcement.id,
            )
        )
        count += 1
    db.commit()
    return count


@app.get("/admin/announcements")
def list_announcements(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    rows = db.query(FeedAnnouncement).order_by(FeedAnnouncement.created_at.desc()).all()
    return [_announcement_out(a, db) for a in rows]


@app.post("/admin/announcements", status_code=201)
def create_announcement(
    data: AnnouncementIn,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ann = FeedAnnouncement(
        title=data.title,
        body=data.body,
        tag=data.tag or "Объявление",
        created_by=admin.id,
    )
    db.add(ann)
    db.commit()
    db.refresh(ann)
    audit(db, admin.id, "create_announcement", "feed_announcement", ann.id)
    return _announcement_out(ann, db)


@app.patch("/admin/announcements/{ann_id}")
def update_announcement(
    ann_id: str,
    data: AnnouncementUpdate,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ann = db.query(FeedAnnouncement).filter(FeedAnnouncement.id == ann_id).first()
    if not ann:
        raise HTTPException(404, "Объявление не найдено")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(ann, field, val)
    ann.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(ann)
    audit(db, admin.id, "update_announcement", "feed_announcement", ann_id)
    return _announcement_out(ann, db)


@app.delete("/admin/announcements/{ann_id}", status_code=204)
def delete_announcement(
    ann_id: str,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ann = db.query(FeedAnnouncement).filter(FeedAnnouncement.id == ann_id).first()
    if not ann:
        raise HTTPException(404, "Объявление не найдено")
    db.delete(ann)
    db.commit()
    audit(db, admin.id, "delete_announcement", "feed_announcement", ann_id)


@app.post("/admin/announcements/{ann_id}/publish")
def publish_announcement(
    ann_id: str,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ann = db.query(FeedAnnouncement).filter(FeedAnnouncement.id == ann_id).first()
    if not ann:
        raise HTTPException(404, "Объявление не найдено")
    now = datetime.now(timezone.utc)
    if not ann.is_published:
        ann.is_published = True
        ann.published_at = now
    ann.updated_at = now
    db.commit()
    db.refresh(ann)
    sent = _dispatch_announcement_notifications(db, ann)
    audit(
        db,
        admin.id,
        "publish_announcement",
        "feed_announcement",
        ann_id,
        {"notifications_sent": sent},
    )
    return {"announcement": _announcement_out(ann, db), "notifications_sent": sent}


@app.post("/admin/announcements/{ann_id}/notify")
def resend_announcement_notifications(
    ann_id: str,
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    ann = db.query(FeedAnnouncement).filter(FeedAnnouncement.id == ann_id).first()
    if not ann:
        raise HTTPException(404, "Объявление не найдено")
    if not ann.is_published:
        raise HTTPException(400, "Сначала опубликуйте объявление на ленте")
    sent = _dispatch_announcement_notifications(db, ann)
    audit(db, admin.id, "notify_announcement", "feed_announcement", ann_id, {"sent": sent})
    return {"notifications_sent": sent}


@app.get("/notifications")
def list_notifications(
    unread_only: bool = False,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    q = db.query(UserNotification).filter(UserNotification.user_id == user.id)
    if unread_only:
        q = q.filter(UserNotification.is_read == False)
    rows = q.order_by(UserNotification.created_at.desc()).limit(50).all()
    return [_notification_out(n) for n in rows]


@app.get("/notifications/unread-count")
def notifications_unread_count(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    count = (
        db.query(UserNotification)
        .filter(UserNotification.user_id == user.id, UserNotification.is_read == False)
        .count()
    )
    return {"count": count}


@app.patch("/notifications/{notif_id}/read")
def mark_notification_read(
    notif_id: str,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    n = (
        db.query(UserNotification)
        .filter(UserNotification.id == notif_id, UserNotification.user_id == user.id)
        .first()
    )
    if not n:
        raise HTTPException(404, "Уведомление не найдено")
    n.is_read = True
    n.read_at = datetime.now(timezone.utc)
    db.commit()
    return _notification_out(n)


@app.post("/notifications/read-all")
def mark_all_notifications_read(
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    now = datetime.now(timezone.utc)
    rows = (
        db.query(UserNotification)
        .filter(UserNotification.user_id == user.id, UserNotification.is_read == False)
        .all()
    )
    for n in rows:
        n.is_read = True
        n.read_at = now
    db.commit()
    return {"marked": len(rows)}


@app.post("/admin/seed-demo")
def seed_demo_endpoint(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    from seed_data import ensure_users, seed_demo_content

    admin_user = ensure_users(db)
    seeded = seed_demo_content(db, admin_user)
    return {"seeded": seeded, "message": "Демо-данные добавлены" if seeded else "Контент уже есть"}


@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0"}
