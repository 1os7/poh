"""Демо-данные и исправление legacy email."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from main import (
    AnswerOption,
    Category,
    Course,
    CourseEnrollment,
    CourseLesson,
    FeedAnnouncement,
    Question,
    Test,
    User,
    UserNotification,
    hash_password,
)

ADMIN_EMAIL = "admin@skillgrid.ru"
ADMIN_PASSWORD = "Admin1234"
DEMO_EMAIL = "demo@skillgrid.ru"
DEMO_PASSWORD = "Demo1234"

LEGACY_EMAIL_MAP = {
    "admin@skillgrid.local": ADMIN_EMAIL,
}


def migrate_legacy_emails(db: Session) -> None:
    for old, new in LEGACY_EMAIL_MAP.items():
        user = db.query(User).filter(User.email == old).first()
        if not user:
            continue
        if db.query(User).filter(User.email == new, User.id != user.id).first():
            db.delete(user)
        else:
            user.email = new
    db.commit()


def ensure_users(db: Session) -> User:
    migrate_legacy_emails(db)
    admin = db.query(User).filter(User.email == ADMIN_EMAIL).first()
    if not admin:
        admin = User(
            email=ADMIN_EMAIL,
            password_hash=hash_password(ADMIN_PASSWORD),
            full_name="Администратор",
            department="HR",
            position="Администратор платформы",
            role="admin",
        )
        db.add(admin)
        db.commit()
        db.refresh(admin)

    if not db.query(User).filter(User.email == DEMO_EMAIL).first():
        db.add(
            User(
                email=DEMO_EMAIL,
                password_hash=hash_password(DEMO_PASSWORD),
                full_name="Анна Демо",
                department="Разработка",
                position="Middle Developer",
                role="employee",
            )
        )
        db.commit()
    return admin


def seed_demo_content(db: Session, admin: User) -> bool:
    """Возвращает True, если данные были добавлены."""
    has_content = (
        db.query(Course).filter(Course.is_published == True).count() > 0
        and db.query(Test).filter(Test.is_published == True).count() > 0
    )
    if has_content:
        return False

    cat_soft = Category(name="Soft skills", description="Коммуникация, лидерство, работа в команде")
    cat_tech = Category(name="Технические навыки", description="Инженерия, безопасность, процессы")
    cat_corp = Category(name="Корпоративные знания", description="Политики, продукт, культура компании")
    db.add_all([cat_soft, cat_tech, cat_corp])
    db.flush()

    courses_spec = [
        {
            "title": "Эффективная коммуникация",
            "description": "Как давать обратную связь, вести встречи и договариваться с коллегами.",
            "category_id": cat_soft.id,
            "passing_score": 70,
            "lessons": [
                {
                    "title": "Активное слушание",
                    "content": "<p>На этом уроке разберём техники активного слушания и типичные ошибки в переписке.</p><ul><li>Перефразирование</li><li>Уточняющие вопросы</li></ul>",
                },
                {
                    "title": "Обратная связь по модели SBI",
                    "content": "<p><strong>S</strong>ituation — <strong>B</strong>ehavior — <strong>I</strong>mpact. Практикуем формулировки на рабочих кейсах.</p>",
                },
                {
                    "title": "Сложные разговоры",
                    "content": "<p>План разговора, деэскалация конфликта, фиксация договорённостей.</p>",
                },
            ],
        },
        {
            "title": "Основы информационной безопасности",
            "description": "Пароли, фишинг, данные клиентов — обязательный минимум для каждого сотрудника.",
            "category_id": cat_tech.id,
            "passing_score": 80,
            "lessons": [
                {
                    "title": "Угрозы и фишинг",
                    "content": "<p>Как распознать подозрительные письма и ссылки. Что делать при инциденте.</p>",
                },
                {
                    "title": "Пароли и 2FA",
                    "content": "<p>Менеджеры паролей, политика компании, двухфакторная аутентификация.</p>",
                },
            ],
        },
        {
            "title": "Онбординг: продукт Skillgrid",
            "description": "Знакомство с платформой, ролями и процессами аттестации в компании.",
            "category_id": cat_corp.id,
            "passing_score": 60,
            "lessons": [
                {
                    "title": "Зачем нам Skillgrid",
                    "content": "<p>Цели платформы: оценка компетенций, развитие, прозрачная аналитика для HR и руководителей.</p>",
                },
                {
                    "title": "Как проходить курсы и тесты",
                    "content": "<p>Лента → курсы → тесты → история. Где смотреть прогресс и результаты.</p>",
                },
                {
                    "title": "Правила и сроки аттестации",
                    "content": "<p>Квартальные цели, проходной балл, повторные попытки.</p>",
                },
            ],
        },
    ]

    course_ids: list[str] = []
    for i, spec in enumerate(courses_spec):
        course = Course(
            title=spec["title"],
            description=spec["description"],
            category_id=spec["category_id"],
            passing_score=spec.get("passing_score", 70),
            is_published=True,
            created_by=admin.id,
        )
        db.add(course)
        db.flush()
        course_ids.append(course.id)
        for pos, les in enumerate(spec["lessons"]):
            db.add(
                CourseLesson(
                    course_id=course.id,
                    title=les["title"],
                    content=les["content"],
                    position=pos,
                )
            )

    tests_spec = [
        {
            "title": "Soft skills: базовый уровень",
            "description": "Итоговая аттестация курса «Эффективная коммуникация».",
            "category_id": cat_soft.id,
            "course_index": 0,
            "duration_minutes": 20,
            "passing_score": 70,
            "questions": [
                {
                    "text": "Что входит в модель SBI?",
                    "type": "single",
                    "options": [
                        ("Situation, Behavior, Impact", True),
                        ("Strategy, Budget, Initiative", False),
                        ("Speed, Balance, Innovation", False),
                    ],
                },
                {
                    "text": "Активное слушание включает перефразирование.",
                    "type": "true_false",
                    "options": [("Верно", True), ("Неверно", False)],
                },
                {
                    "text": "Выберите признаки конструктивной обратной связи:",
                    "type": "multiple",
                    "options": [
                        ("Конкретика и факты", True),
                        ("Оценка личности", False),
                        ("Предложение следующего шага", True),
                        ("Публичное унижение", False),
                    ],
                },
                {
                    "text": "Расставьте этапы модели SBI в правильном порядке:",
                    "type": "drag_drop",
                    "options": [
                        ("Situation — описать контекст", False),
                        ("Behavior — описать поведение", False),
                        ("Impact — описать влияние", False),
                    ],
                },
            ],
        },
        {
            "title": "Информационная безопасность",
            "description": "Итоговая аттестация курса по ИБ. Проходной балл — 80%.",
            "category_id": cat_tech.id,
            "course_index": 1,
            "duration_minutes": 15,
            "passing_score": 80,
            "questions": [
                {
                    "text": "Получили письмо с вложением от неизвестного адреса. Ваши действия?",
                    "type": "single",
                    "options": [
                        ("Сообщить в ИБ, не открывать вложение", True),
                        ("Открыть на личном телефоне", False),
                        ("Переслать коллегам", False),
                    ],
                },
                {
                    "text": "2FA снижает риск взлома аккаунта.",
                    "type": "true_false",
                    "options": [("Верно", True), ("Неверно", False)],
                },
            ],
        },
        {
            "title": "Корпоративная культура Skillgrid",
            "description": "Итоговая аттестация курса онбординга.",
            "category_id": cat_corp.id,
            "course_index": 2,
            "duration_minutes": 10,
            "passing_score": 60,
            "questions": [
                {
                    "text": "Где сотрудник видит рекомендованные курсы и тесты?",
                    "type": "single",
                    "options": [
                        ("На ленте", True),
                        ("Только в email", False),
                        ("В печатном журнале", False),
                    ],
                },
            ],
        },
    ]

    for spec in tests_spec:
        idx = spec.get("course_index")
        linked_course = course_ids[idx] if idx is not None and idx < len(course_ids) else None
        test = Test(
            title=spec["title"],
            description=spec["description"],
            category_id=spec["category_id"],
            course_id=linked_course,
            duration_minutes=spec["duration_minutes"],
            passing_score=spec["passing_score"],
            is_published=True,
            created_by=admin.id,
        )
        db.add(test)
        db.flush()
        for qpos, q in enumerate(spec["questions"]):
            question = Question(
                test_id=test.id,
                question_text=q["text"],
                question_type=q["type"],
                points=1,
                position=qpos,
            )
            db.add(question)
            db.flush()
            for opos, (text, correct) in enumerate(q["options"]):
                db.add(
                    AnswerOption(
                        question_id=question.id,
                        answer_text=text,
                        is_correct=correct,
                        position=opos,
                    )
                )

    db.commit()

    demo = db.query(User).filter(User.email == DEMO_EMAIL).first()
    first_course = db.query(Course).filter(Course.is_published == True).first()
    if demo and first_course:
        if (
            not db.query(CourseEnrollment)
            .filter(
                CourseEnrollment.user_id == demo.id,
                CourseEnrollment.course_id == first_course.id,
            )
            .first()
        ):
            db.add(
                CourseEnrollment(
                    course_id=first_course.id,
                    user_id=demo.id,
                    progress=33,
                )
            )
            db.commit()

    return True


COURSE_TEST_LINKS = [
    ("Эффективная коммуникация", "Soft skills: базовый уровень", 70),
    ("Основы информационной безопасности", "Информационная безопасность", 80),
    ("Онбординг: продукт Skillgrid", "Корпоративная культура Skillgrid", 60),
]


def link_courses_to_final_tests(db: Session) -> None:
    """Для существующей БД: привязать итоговые тесты и проходной балл курса."""
    for course_title, test_title, passing in COURSE_TEST_LINKS:
        course = db.query(Course).filter(Course.title == course_title).first()
        test = db.query(Test).filter(Test.title == test_title).first()
        if course:
            course.passing_score = passing
            if test:
                test.course_id = course.id
                test.passing_score = passing
    db.commit()


def ensure_drag_drop_demo_question(db: Session) -> None:
    test = db.query(Test).filter(Test.title == "Soft skills: базовый уровень").first()
    if not test:
        return
    if (
        db.query(Question)
        .filter(Question.test_id == test.id, Question.question_type == "drag_drop")
        .first()
    ):
        return
    pos = db.query(Question).filter(Question.test_id == test.id).count()
    question = Question(
        test_id=test.id,
        question_text="Расставьте этапы модели SBI в правильном порядке:",
        question_type="drag_drop",
        points=1,
        position=pos,
    )
    db.add(question)
    db.flush()
    for i, text in enumerate(
        [
            "Situation — описать контекст",
            "Behavior — описать поведение",
            "Impact — описать влияние",
        ]
    ):
        db.add(
            AnswerOption(
                question_id=question.id,
                answer_text=text,
                is_correct=False,
                position=i,
            )
        )
    db.commit()


def ensure_feed_announcements(db: Session, admin: User) -> None:
    if db.query(FeedAnnouncement).count() > 0:
        return
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    specs = [
        {
            "title": "Квартальная аттестация",
            "body": "До конца квартала пройдите минимум 2 теста и 1 курс из каталога.",
            "tag": "Важно",
        },
        {
            "title": "Новый курс по коммуникации",
            "body": "Добавлен курс «Эффективная коммуникация» — рекомендуем начать с него.",
            "tag": "Новинка",
        },
    ]
    for spec in specs:
        ann = FeedAnnouncement(
            title=spec["title"],
            body=spec["body"],
            tag=spec["tag"],
            is_published=True,
            published_at=now,
            created_by=admin.id,
        )
        db.add(ann)
        db.flush()
        for u in db.query(User).all():
            db.add(
                UserNotification(
                    user_id=u.id,
                    title=ann.title,
                    body=ann.body,
                    tag=ann.tag,
                    announcement_id=ann.id,
                )
            )
    db.commit()


def run_seed(db: Session) -> None:
    admin = ensure_users(db)
    seed_demo_content(db, admin)
    link_courses_to_final_tests(db)
    ensure_drag_drop_demo_question(db)
    ensure_feed_announcements(db, admin)
