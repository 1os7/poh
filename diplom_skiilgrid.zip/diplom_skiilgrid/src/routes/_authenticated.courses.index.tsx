import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { GraduationCap, Loader2, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { coursesApi } from "@/lib/api";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/EmptyState";
import { QueryError } from "@/components/QueryError";

export const Route = createFileRoute("/_authenticated/courses/")({
  component: CoursesPage,
});

function CoursesPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [startingId, setStartingId] = useState<string | null>(null);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["courses-published"],
    queryFn: () => coursesApi.list(),
  });

  const filtered = (data ?? []).filter(
    (c) => !q || c.title.toLowerCase().includes(q.toLowerCase()),
  );

  const startLearning = async (courseId: string) => {
    setStartingId(courseId);
    try {
      await coursesApi.enroll(courseId);
      navigate({ to: "/courses/$id", params: { id: courseId }, search: { tab: "study" } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Не удалось начать курс");
    } finally {
      setStartingId(null);
    }
  };

  if (isError) {
    return (
      <div>
        <PageHeader
          title="Курсы"
          description="Изучите материалы и сдайте итоговый тест для подтверждения компетенции"
        />
        <QueryError
          message={error instanceof Error ? error.message : "Ошибка"}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Курсы"
        description="Изучите материалы и сдайте итоговый тест — минимальный балл для завершения указан в курсе"
      />

      <div className="mb-5 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Поиск по курсам…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="p-6 animate-pulse h-48 bg-muted/40" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12">
          <EmptyState
            icon={GraduationCap}
            title="Пока нет доступных курсов"
            description="Администратор ещё не опубликовал курсы"
          />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => (
            <Card key={c.id} className="p-6 flex flex-col hover:shadow-elevated transition">
              <div className="flex items-start justify-between gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary-soft text-primary">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <Badge variant="secondary" className="text-xs">
                  {c.lesson_count} уроков
                </Badge>
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{c.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2 flex-1">
                {c.description ?? "Без описания"}
              </p>
              {c.final_test_id && (
                <p className="mt-2 text-xs text-muted-foreground">
                  Итоговый тест · проходной {c.passing_score}%
                </p>
              )}
              {c.enrolled && (
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>Прогресс</span>
                    <span>{c.progress}%</span>
                  </div>
                  <Progress value={c.progress} />
                </div>
              )}
              <Button
                className="w-full mt-4"
                disabled={startingId === c.id}
                onClick={() => startLearning(c.id)}
              >
                {startingId === c.id && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {c.enrolled ? "Продолжить обучение" : "Начать обучение"}
              </Button>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
