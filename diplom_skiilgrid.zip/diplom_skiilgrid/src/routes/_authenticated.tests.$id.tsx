import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { CheckCircle2, Clock, Loader2, Target } from "lucide-react";
import { toast } from "sonner";
import { testsApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { QueryError } from "@/components/QueryError";
import { RouteLinkButton } from "@/components/RouteLinkButton";
import { QuestionPrompt } from "@/components/test/QuestionPrompt";
import { hasAnswer, shuffleOptions, type AnswerValue, type TestQuestion } from "@/lib/test-utils";

type TestSearch = { returnTo?: string };

export const Route = createFileRoute("/_authenticated/tests/$id")({
  validateSearch: (search: Record<string, unknown>): TestSearch => ({
    returnTo: typeof search.returnTo === "string" ? search.returnTo : undefined,
  }),
  component: TakeTestPage,
});

function TakeTestPage() {
  const { id } = Route.useParams();
  const { returnTo: courseId } = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, AnswerValue>>({});
  const [submitting, setSubmitting] = useState(false);
  const [finished, setFinished] = useState<{ score: number; passed: boolean } | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [dragShuffle, setDragShuffle] = useState<Record<string, string[]>>({});

  const { data: test, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["test", id],
    queryFn: async () => {
      const data = await testsApi.get(id);
      return {
        test: {
          id: data.id,
          title: data.title,
          description: data.description,
          duration_minutes: data.duration_minutes,
          passing_score: data.passing_score,
          max_attempts: data.max_attempts,
          can_attempt: data.can_attempt !== false,
          user_attempts_left: data.user_attempts_left,
          user_attempts: data.user_attempts,
        },
        questions: data.questions as TestQuestion[],
      };
    },
  });

  const questions = test?.questions ?? [];
  const current = questions[idx];

  useEffect(() => {
    if (!current || current.question_type !== "drag_drop") return;
    if (dragShuffle[current.id]) return;
    const ids = shuffleOptions(current.answer_options).map((o) => o.id);
    setDragShuffle((s) => ({ ...s, [current.id]: ids }));
    setAnswers((a) => ({ ...a, [current.id]: ids }));
  }, [current?.id, current?.question_type, dragShuffle, current]);

  useEffect(() => {
    if (test?.test?.duration_minutes && secondsLeft === null) {
      setSecondsLeft(test.test.duration_minutes * 60);
    }
  }, [test, secondsLeft]);

  useEffect(() => {
    if (secondsLeft === null || finished) return;
    if (secondsLeft <= 0) {
      void submit();
      return;
    }
    const i = setInterval(() => setSecondsLeft((s) => (s ?? 0) - 1), 1000);
    return () => clearInterval(i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft, finished]);

  const progress = questions.length ? ((idx + 1) / questions.length) * 100 : 0;

  async function submit() {
    if (!test?.test || submitting) return;
    if (!test.test.can_attempt) {
      toast.error("Исчерпан лимит попыток для этого теста");
      return;
    }
    setSubmitting(true);
    try {
      const result = await testsApi.submitAttempt(id, {
        answers: answers as Record<string, unknown>,
        score: 0,
        passed: false,
      });
      setFinished({ score: result.score, passed: result.passed });
      qc.invalidateQueries({ queryKey: ["tests-published"] });
      qc.invalidateQueries({ queryKey: ["feed"] });
      qc.invalidateQueries({ queryKey: ["history"] });
      qc.invalidateQueries({ queryKey: ["my-stats"] });
      if (courseId) {
        qc.invalidateQueries({ queryKey: ["course", courseId] });
        qc.invalidateQueries({ queryKey: ["courses-published"] });
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка отправки");
    } finally {
      setSubmitting(false);
    }
  }

  function goNext() {
    if (!current || !hasAnswer(current, answers)) {
      toast.error("Ответьте на вопрос, чтобы перейти дальше");
      return;
    }
    setIdx((i) => i + 1);
  }

  if (isLoading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="max-w-lg mx-auto">
        <QueryError message={error instanceof Error ? error.message : "Ошибка"} onRetry={() => refetch()} />
      </div>
    );
  }

  if (!test?.test) {
    return <p className="text-muted-foreground">Тест не найден.</p>;
  }

  if (questions.length === 0) {
    return (
      <Card className="p-10 text-center">
        <p className="text-muted-foreground">В тесте пока нет вопросов.</p>
      </Card>
    );
  }

  if (test.test && !test.test.can_attempt) {
    return (
      <Card className="p-10 max-w-xl mx-auto text-center">
        <h2 className="font-display text-xl font-semibold">Лимит попыток исчерпан</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Допустимо попыток: {test.test.max_attempts}. Вы уже прошли тест {test.test.user_attempts}{" "}
          раз(а).
        </p>
      </Card>
    );
  }

  if (finished) {
    const passScore = test.test.passing_score ?? 70;
    return (
      <Card className="p-10 max-w-xl mx-auto text-center">
        <div
          className={
            "mx-auto grid h-14 w-14 place-items-center rounded-full " +
            (finished.passed ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive")
          }
        >
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h2 className="mt-4 font-display text-2xl font-semibold">Аттестация завершена</h2>
        <p className="mt-2 text-muted-foreground">
          Балл: <span className="font-semibold text-foreground">{finished.score.toFixed(1)}%</span>
          <span className="text-muted-foreground"> · проходной {passScore}%</span>
        </p>
        <Badge
          className={
            "mt-3 " +
            (finished.passed
              ? "bg-success text-success-foreground"
              : "bg-destructive text-destructive-foreground")
          }
        >
          {finished.passed ? "Компетенция подтверждена" : "Требуется повторное прохождение"}
        </Badge>
        <div className="mt-6 flex flex-wrap gap-2 justify-center">
          {courseId && (
            <Button
              onClick={() =>
                navigate({
                  to: "/courses/$id",
                  params: { id: courseId },
                  search: { tab: "test" },
                })
              }
            >
              Вернуться к курсу
            </Button>
          )}
          <Button variant="outline" onClick={() => navigate({ to: "/history" })}>
            История
          </Button>
          <Button variant="outline" onClick={() => navigate({ to: "/tests" })}>
            Другие тесты
          </Button>
        </div>
      </Card>
    );
  }

  const mm = String(Math.floor((secondsLeft ?? 0) / 60)).padStart(2, "0");
  const ss = String((secondsLeft ?? 0) % 60).padStart(2, "0");

  const attemptsHint =
    test.test.max_attempts > 0
      ? `Попытка ${(test.test.user_attempts ?? 0) + 1} из ${test.test.max_attempts}`
      : null;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-end gap-3 text-sm mb-4">
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <Target className="h-4 w-4" /> проходной {test.test.passing_score}%
        </span>
        {attemptsHint && (
          <span className="text-muted-foreground">{attemptsHint}</span>
        )}
        <span className="inline-flex items-center gap-1.5 font-medium tabular-nums">
          <Clock className="h-4 w-4 text-muted-foreground" /> {mm}:{ss}
        </span>
      </div>

      <h1 className="font-display text-2xl font-semibold">{test.test.title}</h1>
      {test.test.description && (
        <p className="mt-1 text-sm text-muted-foreground">{test.test.description}</p>
      )}
      <Progress value={progress} className="mt-4" />
      <p className="mt-2 text-xs text-muted-foreground">
        Вопрос {idx + 1} из {questions.length}
      </p>

      {current && (
        <Card className="p-6 mt-5">
          <div className="text-base font-medium">{current.question_text}</div>
          <div className="mt-5 space-y-2.5">
            <QuestionPrompt
              question={current}
              value={answers[current.id]}
              shuffledOptionIds={dragShuffle[current.id]}
              onChange={(v) => setAnswers((a) => ({ ...a, [current.id]: v }))}
            />
          </div>
        </Card>
      )}

      <div className="mt-5 flex justify-between gap-2">
        <Button variant="outline" disabled={idx === 0} onClick={() => setIdx((i) => i - 1)}>
          Назад
        </Button>
        {idx < questions.length - 1 ? (
          <Button onClick={goNext}>Далее</Button>
        ) : (
          <Button
            onClick={() => {
              if (!current || !hasAnswer(current, answers)) {
                toast.error("Ответьте на последний вопрос");
                return;
              }
              void submit();
            }}
            disabled={submitting}
          >
            {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Завершить и отправить
          </Button>
        )}
      </div>
    </div>
  );
}
