import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { BookOpen, CheckCircle2, Loader2, Lock, PlayCircle, Target } from "lucide-react";
import { toast } from "sonner";
import { coursesApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { QueryError } from "@/components/QueryError";
import { RouteLinkButton } from "@/components/RouteLinkButton";

type CourseSearch = { tab?: "study" | "test" };

export const Route = createFileRoute("/_authenticated/courses/$id")({
  validateSearch: (search: Record<string, unknown>): CourseSearch => ({
    tab: search.tab === "test" ? "test" : "study",
  }),
  component: CourseDetailPage,
});

function CourseDetailPage() {
  const { id } = Route.useParams();
  const { tab } = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const activeTab = tab ?? "study";

  const {
    data: course,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ["course", id],
    queryFn: () => coursesApi.get(id),
  });

  const { data: lessons, isLoading: lessonsLoading } = useQuery({
    queryKey: ["course-lessons", id],
    queryFn: () => coursesApi.listLessons(id),
    enabled: !!course,
  });

  useEffect(() => {
    if (!course?.enrolled && course) {
      coursesApi.enroll(id).then(() => {
        qc.invalidateQueries({ queryKey: ["course", id] });
        qc.invalidateQueries({ queryKey: ["courses-published"] });
      });
    }
  }, [course?.enrolled, course, id, qc]);

  useEffect(() => {
    if (!lessons?.length) return;
    const firstOpen = lessons.find((l) => !l.completed) ?? lessons[0];
    if (!activeLessonId || !lessons.some((l) => l.id === activeLessonId)) {
      setActiveLessonId(firstOpen.id);
    }
  }, [lessons, activeLessonId]);

  const completeMut = useMutation({
    mutationFn: (lessonId: string) => coursesApi.completeLesson(id, lessonId),
    onSuccess: () => {
      toast.success("Урок отмечен как пройденный");
      qc.invalidateQueries({ queryKey: ["course", id] });
      qc.invalidateQueries({ queryKey: ["course-lessons", id] });
      qc.invalidateQueries({ queryKey: ["courses-published"] });
      qc.invalidateQueries({ queryKey: ["my-courses"] });
      qc.invalidateQueries({ queryKey: ["feed"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const activeLesson = lessons?.find((l) => l.id === activeLessonId) ?? lessons?.[0];

  const setTab = (next: "study" | "test") => {
    navigate({ to: "/courses/$id", params: { id }, search: { tab: next }, replace: true });
  };

  if (isLoading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="max-w-lg mx-auto">
        <QueryError message={error instanceof Error ? error.message : "Ошибка"} onRetry={() => refetch()} />
      </div>
    );
  }

  if (!course) {
    return <p className="text-muted-foreground">Курс не найден.</p>;
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold">{course.title}</h1>
          <p className="mt-2 text-muted-foreground">{course.description ?? "Без описания"}</p>
          {course.final_test_id && (
            <p className="mt-2 text-sm text-muted-foreground">
              Для завершения курса: все уроки + итоговый тест от {course.passing_score}%
            </p>
          )}
        </div>
        <div className="min-w-[220px]">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-muted-foreground">Прогресс</span>
            <span className="font-medium">{course.progress}%</span>
          </div>
          <Progress value={course.progress} />
          {course.course_completed && (
            <Badge className="mt-2 bg-success text-success-foreground">Курс пройден</Badge>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setTab(v as "study" | "test")}>
        <TabsList className="mb-4">
          <TabsTrigger value="study" className="gap-2">
            <BookOpen className="h-4 w-4" />
            Материалы
            {course.lessons_total > 0 && (
              <span className="text-muted-foreground text-xs">
                {course.lessons_completed}/{course.lessons_total}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="test" className="gap-2" disabled={!course.final_test_id}>
            <Target className="h-4 w-4" />
            Итоговая аттестация
          </TabsTrigger>
        </TabsList>

        <TabsContent value="study">
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="p-4 lg:col-span-1 h-fit">
              <h2 className="font-display font-semibold mb-3">Уроки</h2>
              {lessonsLoading ? (
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              ) : !lessons || lessons.length === 0 ? (
                <p className="text-sm text-muted-foreground">Уроки ещё не добавлены.</p>
              ) : (
                <ul className="space-y-1">
                  {lessons.map((l, i) => (
                    <li key={l.id}>
                      <button
                        type="button"
                        onClick={() => setActiveLessonId(l.id)}
                        className={
                          "w-full text-left rounded-lg px-3 py-2 text-sm transition flex items-center gap-2 " +
                          (activeLesson?.id === l.id
                            ? "bg-sidebar-accent font-medium"
                            : "hover:bg-muted")
                        }
                      >
                        <span className="text-muted-foreground shrink-0">{i + 1}.</span>
                        <span className="flex-1 truncate">{l.title}</span>
                        {l.completed && (
                          <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
                        )}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </Card>

            <Card className="p-6 lg:col-span-2 min-h-[320px]">
              {!activeLesson ? (
                <p className="text-muted-foreground text-center py-12">Загрузка уроков…</p>
              ) : (
                <>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-xl font-semibold">{activeLesson.title}</h3>
                    {!activeLesson.completed ? (
                      <Button
                        size="sm"
                        className="gap-1.5 shrink-0"
                        onClick={() => completeMut.mutate(activeLesson.id)}
                        disabled={completeMut.isPending}
                      >
                        {completeMut.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="h-4 w-4" />
                        )}
                        Завершить урок
                      </Button>
                    ) : (
                      <Badge variant="secondary" className="gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5" /> Пройден
                      </Badge>
                    )}
                  </div>

                  {activeLesson.video_url && (
                    <a
                      href={activeLesson.video_url}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-4 inline-flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      <PlayCircle className="h-4 w-4" />
                      Смотреть видео
                    </a>
                  )}

                  {activeLesson.content ? (
                    <div
                      className="mt-5 prose prose-sm max-w-none text-foreground"
                      dangerouslySetInnerHTML={{ __html: activeLesson.content }}
                    />
                  ) : (
                    <p className="mt-5 text-sm text-muted-foreground">
                      Содержимое урока пока не заполнено.
                    </p>
                  )}

                  {course.all_lessons_completed && course.final_test_id && (
                    <div className="mt-8 p-4 rounded-lg border border-border bg-muted/30">
                      <p className="text-sm font-medium">Все уроки пройдены</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Перейдите к итоговой аттестации, чтобы завершить курс.
                      </p>
                      <Button className="mt-3" size="sm" onClick={() => setTab("test")}>
                        К итоговому тесту
                      </Button>
                    </div>
                  )}
                </>
              )}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="test">
          <Card className="p-8 max-w-xl mx-auto text-center">
            {!course.final_test_id ? (
              <p className="text-muted-foreground">Для этого курса итоговый тест не настроен.</p>
            ) : !course.can_take_final_test ? (
              <>
                <Lock className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                <h3 className="font-display text-lg font-semibold">Сначала пройдите все уроки</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Пройдено {course.lessons_completed} из {course.lessons_total} уроков. После этого
                  откроется итоговый тест.
                </p>
                <Button className="mt-4" variant="outline" onClick={() => setTab("study")}>
                  К материалам
                </Button>
              </>
            ) : course.final_test_passed || course.course_completed ? (
              <>
                <CheckCircle2 className="h-10 w-10 mx-auto text-success mb-3" />
                <h3 className="font-display text-lg font-semibold">Итоговый тест сдан</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Курс считается пройденным при балле от {course.passing_score}%.
                </p>
              </>
            ) : (
              <>
                <Target className="h-10 w-10 mx-auto text-primary mb-3" />
                <h3 className="font-display text-lg font-semibold">
                  {course.final_test_title ?? "Итоговая аттестация"}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Тест с таймером и автопроверкой. Проходной балл для курса: {course.passing_score}%
                </p>
                <RouteLinkButton
                  to="/tests/$id"
                  params={{ id: course.final_test_id }}
                  search={{ returnTo: id }}
                  className="mt-6"
                >
                  Начать итоговый тест
                </RouteLinkButton>
              </>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
