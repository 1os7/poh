import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BarChart3,
  CheckCircle2,
  GraduationCap,
  LineChart,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Skillgrid — корпоративная оценка компетенций" },
      {
        name: "description",
        content:
          "Skillgrid — платформа уровня enterprise для тестирования сотрудников, аттестации и аналитики компетенций.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <Stats />
      <Features />
      <HowItWorks />
      <Testimonials />
      <FAQ />
      <CTA />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 backdrop-blur-md bg-background/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--gradient-primary)] text-white shadow-soft">
            <GraduationCap className="h-5 w-5" />
          </div>
          <span className="font-display text-lg font-semibold tracking-tight">Skillgrid</span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground transition">Возможности</a>
          <a href="#how" className="hover:text-foreground transition">Как это работает</a>
          <a href="#faq" className="hover:text-foreground transition">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/login">
            <Button variant="ghost" size="sm">Войти</Button>
          </Link>
          <Link to="/register">
            <Button size="sm">Начать бесплатно</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section
      className="relative overflow-hidden"
      style={{ backgroundImage: "var(--gradient-hero)" }}
    >
      <div className="mx-auto max-w-7xl px-6 py-24 md:py-32">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/70 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Enterprise-платформа оценки знаний и навыков
          </div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold tracking-tight">
            Оценивайте компетенции команды <span className="text-gradient">точно и без рутины</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Skillgrid помогает HR и руководителям проводить аттестации, тестировать знания
            и видеть рост каждого сотрудника в одном современном интерфейсе.
          </p>
          <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link to="/register">
              <Button size="lg" className="gap-2">
                Создать аккаунт <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline">Войти в систему</Button>
            </Link>
          </div>
        </div>

        <div className="relative mt-20">
          <div className="mx-auto max-w-5xl rounded-2xl border border-border/60 bg-card shadow-elevated overflow-hidden">
            <div className="flex items-center gap-1.5 border-b border-border/60 bg-muted/40 px-4 py-2.5">
              <span className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-warning/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-success/70" />
              <span className="ml-3 text-xs text-muted-foreground">app.skillgrid / dashboard</span>
            </div>
            <div className="grid md:grid-cols-3 gap-4 p-6">
              <Card className="p-5">
                <div className="text-xs text-muted-foreground">Средний балл</div>
                <div className="mt-2 font-display text-3xl font-semibold">82.4%</div>
                <div className="mt-1 text-xs text-success">+4.2% за месяц</div>
              </Card>
              <Card className="p-5">
                <div className="text-xs text-muted-foreground">Активные тесты</div>
                <div className="mt-2 font-display text-3xl font-semibold">24</div>
                <div className="mt-1 text-xs text-muted-foreground">в 6 категориях</div>
              </Card>
              <Card className="p-5">
                <div className="text-xs text-muted-foreground">Прохождений за неделю</div>
                <div className="mt-2 font-display text-3xl font-semibold">1 248</div>
                <div className="mt-1 text-xs text-success">+18%</div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const items = [
    { v: "120+", l: "компаний" },
    { v: "50 000+", l: "сотрудников" },
    { v: "98%", l: "успешных аттестаций" },
    { v: "4.9/5", l: "оценка HR-команд" },
  ];
  return (
    <section className="border-y border-border/60 bg-muted/30">
      <div className="mx-auto grid max-w-7xl grid-cols-2 md:grid-cols-4 px-6 py-10 gap-6">
        {items.map((i) => (
          <div key={i.l} className="text-center">
            <div className="font-display text-3xl font-semibold">{i.v}</div>
            <div className="mt-1 text-sm text-muted-foreground">{i.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Features() {
  const items = [
    {
      icon: GraduationCap,
      title: "Конструктор тестов",
      desc: "Создавайте тесты с 4 типами вопросов, таймером и случайным порядком. Черновики и автосохранение.",
    },
    {
      icon: BarChart3,
      title: "Глубокая аналитика",
      desc: "Графики успеваемости, разбор ошибок, сравнение отделов и динамика компетенций.",
    },
    {
      icon: Users,
      title: "Управление ролями",
      desc: "RBAC, отделы и должности. Назначайте тесты группам и контролируйте сроки.",
    },
    {
      icon: ShieldCheck,
      title: "Безопасность enterprise",
      desc: "JWT-авторизация, RLS на уровне БД, аудит действий и защита от утечек.",
    },
    {
      icon: LineChart,
      title: "Прогресс и сертификаты",
      desc: "Личный кабинет сотрудника с историей попыток, прогрессом и достижениями.",
    },
    {
      icon: CheckCircle2,
      title: "Готово к запуску",
      desc: "Современный UI, тёмная тема, адаптивность и быстрый онбординг команды.",
    },
  ];
  return (
    <section id="features" className="mx-auto max-w-7xl px-6 py-24">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Возможности</p>
        <h2 className="mt-2 font-display text-3xl md:text-4xl font-semibold tracking-tight">
          Всё для оценки компетенций — в одном продукте
        </h2>
        <p className="mt-4 text-muted-foreground">
          От создания теста до экспорта аналитики: Skillgrid закрывает весь цикл оценки
          без интеграций с десятком сервисов.
        </p>
      </div>
      <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {items.map((f) => (
          <Card key={f.title} className="p-6 hover:shadow-elevated transition-shadow">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary-soft text-primary">
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { n: "01", t: "Добавьте сотрудников", d: "Импортируйте команду или пригласите по email. Раздайте роли и отделы." },
    { n: "02", t: "Соберите тесты", d: "Используйте конструктор: вопросы, баллы, таймер, лимит попыток." },
    { n: "03", t: "Назначьте и запустите", d: "Сотрудники проходят тесты в удобном интерфейсе на любом устройстве." },
    { n: "04", t: "Анализируйте результаты", d: "Видьте прогресс, слабые места и принимайте решения по обучению." },
  ];
  return (
    <section id="how" className="bg-muted/30 border-y border-border/60">
      <div className="mx-auto max-w-7xl px-6 py-24">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Как это работает</p>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-semibold tracking-tight">
            Запуск аттестации — за 30 минут
          </h2>
        </div>
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map((s) => (
            <Card key={s.n} className="p-6">
              <div className="font-display text-sm font-semibold text-primary">{s.n}</div>
              <h3 className="mt-2 font-display text-lg font-semibold">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.d}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const items = [
    {
      q: "Skillgrid заменил нам три инструмента. Аттестация теперь не вызывает паники у HR.",
      a: "Анна Левина",
      r: "HRD, ритейл-сеть",
    },
    {
      q: "Конструктор тестов реально удобный. За день собрали 12 тестов для онбординга.",
      a: "Денис Мирский",
      r: "Head of L&D, IT-компания",
    },
    {
      q: "Аналитика по отделам — то, чего не хватало. Видно, кому нужно обучение.",
      a: "Мария Орлова",
      r: "Руководитель направления",
    },
  ];
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <p className="text-sm font-medium text-primary">Отзывы</p>
      <h2 className="mt-2 font-display text-3xl md:text-4xl font-semibold tracking-tight max-w-xl">
        Команды, которые уже используют Skillgrid
      </h2>
      <div className="mt-12 grid md:grid-cols-3 gap-5">
        {items.map((t) => (
          <Card key={t.a} className="p-6">
            <p className="text-base leading-relaxed">«{t.q}»</p>
            <div className="mt-5 flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-[var(--gradient-primary)]" />
              <div>
                <div className="text-sm font-medium">{t.a}</div>
                <div className="text-xs text-muted-foreground">{t.r}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}

function FAQ() {
  const qs = [
    { q: "Можно ли использовать без интеграций?", a: "Да, Skillgrid работает из коробки. Достаточно зарегистрироваться и пригласить команду." },
    { q: "Какие типы вопросов поддерживаются?", a: "Один ответ, несколько ответов, текст и правда/ложь. В дорожной карте — сопоставление и практические задания." },
    { q: "Как защищены данные?", a: "Шифрование при передаче и хранении, RLS на уровне БД, аудит действий, JWT-сессии." },
    { q: "Подходит ли для крупных компаний?", a: "Да. Платформа спроектирована под enterprise-нагрузку и масштабируется горизонтально." },
  ];
  return (
    <section id="faq" className="bg-muted/30 border-y border-border/60">
      <div className="mx-auto max-w-3xl px-6 py-24">
        <p className="text-sm font-medium text-primary">FAQ</p>
        <h2 className="mt-2 font-display text-3xl md:text-4xl font-semibold tracking-tight">
          Частые вопросы
        </h2>
        <Accordion type="single" collapsible className="mt-8">
          {qs.map((item, i) => (
            <AccordionItem key={i} value={`i${i}`}>
              <AccordionTrigger className="text-left">{item.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{item.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <div className="rounded-3xl border border-border/60 bg-card p-10 md:p-14 shadow-elevated relative overflow-hidden">
        <div
          aria-hidden
          className="absolute -top-32 -right-20 h-80 w-80 rounded-full opacity-30 blur-3xl"
          style={{ background: "var(--gradient-primary)" }}
        />
        <div className="relative max-w-2xl">
          <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight">
            Готовы измерить компетенции команды?
          </h2>
          <p className="mt-3 text-muted-foreground">
            Бесплатный доступ для команд до 25 человек. Без карты, без ограничений по функционалу.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <Link to="/register">
              <Button size="lg" className="gap-2">Начать сейчас <ArrowRight className="h-4 w-4" /></Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline">У меня уже есть аккаунт</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/60">
      <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--gradient-primary)] text-white">
            <GraduationCap className="h-4 w-4" />
          </div>
          <span className="font-display font-semibold text-foreground">Skillgrid</span>
          <span>© {new Date().getFullYear()}</span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#features" className="hover:text-foreground">Возможности</a>
          <a href="#faq" className="hover:text-foreground">FAQ</a>
          <Link to="/login" className="hover:text-foreground">Войти</Link>
        </div>
      </div>
    </footer>
  );
}
