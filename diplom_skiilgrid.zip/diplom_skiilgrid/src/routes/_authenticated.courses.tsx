import { createFileRoute, Outlet } from "@tanstack/react-router";

/** Layout: дочерние маршруты /courses/$id рендерятся через Outlet */
export const Route = createFileRoute("/_authenticated/courses")({
  component: () => <Outlet />,
});
