import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ClipboardList } from "lucide-react";
import { testsApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/AppShell";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/EmptyState";

export const Route = createFileRoute("/_authenticated/history")({
  component: HistoryPage,
});

function HistoryPage() {
  const { data } = useQuery({
    queryKey: ["history"],
    queryFn: () => testsApi.myAttempts(),
  });

  return (
    <div>
      <PageHeader title="История попыток" description="Все ваши прохождения тестов" />
      <Card className="p-0 overflow-hidden">
        {!data || data.length === 0 ? (
          <div className="p-12">
            <EmptyState
              icon={ClipboardList}
              title="Истории пока нет"
              description="После первого пройденного теста результаты появятся здесь"
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Тест</TableHead>
                <TableHead>Дата</TableHead>
                <TableHead>Балл</TableHead>
                <TableHead>Статус</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">{a.test_title ?? "—"}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {new Date(a.started_at).toLocaleString("ru-RU")}
                  </TableCell>
                  <TableCell>
                    {a.score != null ? `${Number(a.score).toFixed(1)}%` : "—"}
                  </TableCell>
                  <TableCell>
                    {a.completed_at == null ? (
                      <Badge variant="secondary">В процессе</Badge>
                    ) : a.passed ? (
                      <Badge className="bg-success text-success-foreground">Пройдено</Badge>
                    ) : (
                      <Badge variant="destructive">Не пройдено</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
