import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ScrollText } from "lucide-react";
import { adminApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/AppShell";
import { AdminOnly } from "@/components/AdminOnly";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/audit")({
  component: () => (
    <AdminOnly>
      <AuditPage />
    </AdminOnly>
  ),
});

function AuditPage() {
  const { data } = useQuery({
    queryKey: ["audit-logs"],
    queryFn: () => adminApi.audit(),
  });

  return (
    <div>
      <PageHeader title="Журнал действий" description="Последние операции в системе" />
      <Card className="p-0 overflow-hidden">
        {!data || data.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground">
            <ScrollText className="h-6 w-6 mx-auto mb-2" />
            Записей пока нет
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Дата</TableHead>
                <TableHead>Действие</TableHead>
                <TableHead>Объект</TableHead>
                <TableHead>Пользователь</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="text-muted-foreground text-xs">
                    {new Date(l.created_at).toLocaleString("ru-RU")}
                  </TableCell>
                  <TableCell className="font-medium">{l.action}</TableCell>
                  <TableCell className="text-muted-foreground">{l.entity ?? "—"}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">
                    {l.user_id?.slice(0, 8) ?? "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
