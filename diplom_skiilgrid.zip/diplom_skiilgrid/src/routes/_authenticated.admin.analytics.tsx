import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { adminApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/AppShell";
import { AdminOnly } from "@/components/AdminOnly";
import { QueryError } from "@/components/QueryError";
import { Loader2 } from "lucide-react";

const CHART_COLORS = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

export const Route = createFileRoute("/_authenticated/admin/analytics")({
  component: () => (
    <AdminOnly>
      <AnalyticsPage />
    </AdminOnly>
  ),
});

function AnalyticsPage() {
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["admin-analytics"],
    queryFn: () => adminApi.analytics(),
  });

  if (isLoading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <div>
        <PageHeader title="Аналитика" description="Данные из попыток прохождения тестов" />
        <QueryError
          message={error instanceof Error ? error.message : "Ошибка"}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  const months = data?.score_by_month ?? [];
  const departments = (data?.by_department ?? []).map((d, i) => ({
    ...d,
    color: CHART_COLORS[i % CHART_COLORS.length],
  }));

  return (
    <div>
      <PageHeader title="Аналитика" description="Реальные данные по попыткам и отделам" />
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-6 lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">Средний балл по месяцам</h2>
          <p className="text-xs text-muted-foreground mt-1">Последние {months.length || 0} месяцев с попытками</p>
          <div className="mt-4 h-72">
            {months.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-16">
                Пока нет завершённых попыток
              </p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={months}>
                  <defs>
                    <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                    }}
                    formatter={(value: number, _n, item) => [
                      `${value}% (${(item.payload as { attempts: number }).attempts} попыток)`,
                      "Средний балл",
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="avg_score"
                    stroke="var(--primary)"
                    strokeWidth={2.5}
                    fill="url(#g)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-lg font-semibold">Попытки по отделам</h2>
          <div className="mt-4 h-72">
            {departments.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-16">Нет данных</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={departments} dataKey="attempts" nameKey="name" innerRadius={56} outerRadius={88}>
                    {departments.map((d, i) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                    }}
                    formatter={(value: number, _n, item) => {
                      const p = item.payload as { share: number; pass_rate: number };
                      return [`${value} (${p.share}%)`, `Успешных: ${p.pass_rate}%`];
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="mt-2 space-y-1.5 max-h-32 overflow-y-auto">
            {departments.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-sm">
                <span className="inline-flex items-center gap-2 truncate">
                  <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: d.color }} />
                  {d.name}
                </span>
                <span className="text-muted-foreground shrink-0 ml-2">
                  {d.attempts} · {d.pass_rate}%
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
