import { createFileRoute, Navigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" />;

  // Pick variant based on URL — admin layout for /admin/*, employee otherwise.
  const variant: "admin" | "employee" =
    typeof window !== "undefined" && window.location.pathname.startsWith("/admin")
      ? "admin"
      : "employee";

  return <AppShell variant={variant} />;
}
