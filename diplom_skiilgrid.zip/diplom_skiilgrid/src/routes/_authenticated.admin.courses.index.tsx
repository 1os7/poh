import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { GraduationCap, Plus, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { coursesApi } from "@/lib/api";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { RouteLinkButton } from "@/components/RouteLinkButton";

export const Route = createFileRoute("/_authenticated/admin/courses/")({
  component: AdminCoursesPage,
});

function AdminCoursesPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    passing_score: 70,
  });

  const { data, isLoading } = useQuery({
    queryKey: ["admin-courses"],
    queryFn: () => coursesApi.list(),
  });

  const filtered = (data ?? []).filter(
    (c) => !q || c.title.toLowerCase().includes(q.toLowerCase()),
  );

  const create = async () => {
    if (!form.title.trim()) return toast.error("Введите название");
    try {
      const course = await coursesApi.create({
        title: form.title,
        description: form.description || undefined,
        passing_score: form.passing_score,
      });
      toast.success("Курс создан — добавьте уроки");
      setOpen(false);
      setForm({ title: "", description: "", passing_score: 70 });
      qc.invalidateQueries({ queryKey: ["admin-courses"] });
      navigate({ to: "/admin/courses/$id", params: { id: course.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const togglePublish = async (id: string, val: boolean) => {
    try {
      await coursesApi.update(id, { is_published: val });
      toast.success(val ? "Опубликовано" : "Снято с публикации");
      qc.invalidateQueries({ queryKey: ["admin-courses"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  return (
    <div>
      <PageHeader
        title="Курсы"
        description="Создайте курс, добавьте уроки с материалами и привяжите итоговый тест"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" /> Новый курс
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Создать курс</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Название</Label>
                  <Input
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Описание</Label>
                  <Textarea
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Проходной балл итогового теста (%)</Label>
                  <Input
                    type="number"
                    min={1}
                    max={100}
                    value={form.passing_score}
                    onChange={(e) =>
                      setForm({ ...form, passing_score: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={create}>Создать и добавить уроки</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="mb-5 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Поиск…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="p-6 animate-pulse h-40 bg-muted/40" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center text-muted-foreground">
          <GraduationCap className="h-8 w-8 mx-auto mb-2" />
          Курсов нет. Нажмите «Новый курс».
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => (
            <Card key={c.id} className="p-5 flex flex-col">
              <div className="flex justify-between gap-2">
                <h3 className="font-display font-semibold">{c.title}</h3>
                {c.is_published ? (
                  <Badge className="bg-success text-success-foreground shrink-0">Live</Badge>
                ) : (
                  <Badge variant="secondary">Черновик</Badge>
                )}
              </div>
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2 flex-1">
                {c.description ?? "Без описания"}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                {c.lesson_count} уроков · проходной {c.passing_score ?? 70}%
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <RouteLinkButton
                  to="/admin/courses/$id"
                  params={{ id: c.id }}
                  size="sm"
                  className="flex-1"
                >
                  Уроки и материалы
                </RouteLinkButton>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => togglePublish(c.id, !c.is_published)}
                >
                  {c.is_published ? "Снять" : "Опубликовать"}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
