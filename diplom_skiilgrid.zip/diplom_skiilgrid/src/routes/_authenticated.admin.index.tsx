import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, CheckCircle2, GraduationCap, TrendingUp, Users } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { adminApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/AppShell";
import { AdminOnly } from "@/components/AdminOnly";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: () => (
    <AdminOnly>
      <Overview />
    </AdminOnly>
  ),
});

function Overview() {
  const { data } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: () => adminApi.stats(),
  });

  const { data: analytics } = useQuery({
    queryKey: ["admin-analytics"],
    queryFn: () => adminApi.analytics(),
  });

  const chart = analytics?.activity_by_day ?? [];

  return (
    <div>
      <PageHeader title="Обзор" description="Ключевые метрики платформы" />
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <Stat icon={Users} label="Сотрудники" value={data?.users ?? 0} />
        <Stat icon={BookOpen} label="Активные тесты" value={data?.active_tests ?? 0} />
        <Stat icon={GraduationCap} label="Активные курсы" value={data?.active_courses ?? 0} />
        <Stat icon={TrendingUp} label="Средний балл" value={`${(data?.avg_score ?? 0).toFixed(1)}%`} />
        <Stat icon={CheckCircle2} label="% успешных" value={`${(data?.pass_rate ?? 0).toFixed(0)}%`} />
      </div>

      <Card className="p-6 mt-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Активность за неделю</h2>
          <span className="text-xs text-muted-foreground">Прохождения по дням</span>
        </div>
        <div className="mt-4 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
              <YAxis stroke="var(--muted-foreground)" fontSize={12} />
              <Tooltip
                contentStyle={{
                  background: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                }}
              />
              <Bar dataKey="count" fill="var(--primary)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        <span className="text-xs">{label}</span>
      </div>
      <div className="mt-3 font-display text-3xl font-semibold">{value}</div>
    </Card>
  );
}
