import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { testsApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { RouteLinkButton } from "@/components/RouteLinkButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/AppShell";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/admin/tests/")({
  component: AdminTestsPage,
});

function AdminTestsPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    duration_minutes: 30,
    passing_score: 70,
    max_attempts: 3,
  });

  const { data } = useQuery({
    queryKey: ["admin-tests"],
    queryFn: () => testsApi.list(),
  });

  const create = async () => {
    if (!form.title.trim()) return toast.error("Введите название");
    try {
      const test = await testsApi.create({
        title: form.title,
        description: form.description || undefined,
        duration_minutes: form.duration_minutes,
        passing_score: form.passing_score,
        max_attempts: form.max_attempts,
      });
      toast.success("Тест создан — добавьте вопросы");
      setOpen(false);
      setForm({
        title: "",
        description: "",
        duration_minutes: 30,
        passing_score: 70,
        max_attempts: 3,
      });
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
      navigate({ to: "/admin/tests/$id", params: { id: test.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const togglePublish = async (id: string, val: boolean) => {
    try {
      await testsApi.update(id, { is_published: val });
      toast.success(val ? "Опубликовано" : "Снято с публикации");
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const removeTest = async (testId: string, title: string) => {
    if (
      !confirm(
        `Удалить тест «${title}»?\n\nВсе вопросы и попытки сотрудников будут удалены безвозвратно.`,
      )
    ) {
      return;
    }
    try {
      await testsApi.delete(testId);
      toast.success("Тест удалён");
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
      qc.invalidateQueries({ queryKey: ["tests-published"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  return (
    <div>
      <PageHeader
        title="Тесты"
        description="Создайте тест, затем в редакторе добавьте вопросы и варианты ответов"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" /> Новый тест
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Создать тест</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Название</Label>
                  <Input
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Описание</Label>
                  <Textarea
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Время (мин)</Label>
                    <Input
                      type="number"
                      min={1}
                      value={form.duration_minutes}
                      onChange={(e) =>
                        setForm({ ...form, duration_minutes: Number(e.target.value) })
                      }
                    />
                  </div>
                  <div>
                    <Label>Проходной балл (%)</Label>
                    <Input
                      type="number"
                      min={1}
                      max={100}
                      value={form.passing_score}
                      onChange={(e) =>
                        setForm({ ...form, passing_score: Number(e.target.value) })
                      }
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Лимит попыток (0 = без лимита)</Label>
                    <Input
                      type="number"
                      min={0}
                      value={form.max_attempts}
                      onChange={(e) =>
                        setForm({ ...form, max_attempts: Number(e.target.value) })
                      }
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={create}>Создать и настроить вопросы</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {!data || data.length === 0 ? (
        <Card className="p-12 text-center text-muted-foreground">
          <BookOpen className="h-6 w-6 mx-auto mb-2" />
          Тестов пока нет. Нажмите «Новый тест».
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.map((t) => (
            <Card key={t.id} className="p-5 flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display font-semibold">{t.title}</h3>
                {t.is_published ? (
                  <Badge className="bg-success text-success-foreground">Опубликован</Badge>
                ) : (
                  <Badge variant="secondary">Черновик</Badge>
                )}
              </div>
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2 flex-1">
                {t.description ?? "Без описания"}
              </p>
              <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span>{t.duration_minutes} мин</span>
                <span>проходной {t.passing_score}%</span>
                <span>
                  попыток: {t.max_attempts > 0 ? t.max_attempts : "∞"}
                </span>
                <span>{t.question_count ?? 0} вопр.</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <RouteLinkButton
                  to="/admin/tests/$id"
                  params={{ id: t.id }}
                  size="sm"
                  className="flex-1"
                >
                  Вопросы и настройки
                </RouteLinkButton>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => togglePublish(t.id, !t.is_published)}
                >
                  {t.is_published ? "Снять" : "Опубликовать"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => removeTest(t.id, t.title)}
                  aria-label="Удалить тест"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
