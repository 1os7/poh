import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowDown,
  ArrowUp,
  LayoutTemplate,
  Megaphone,
  Pencil,
  Plus,
  Save,
  Send,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  adminApi,
  coursesApi,
  testsApi,
  type Announcement,
  type FeedBlock,
} from "@/lib/api";
import {
  BLOCK_LABELS,
  type FeedBlockType,
  newFeedBlock,
  numConfig,
  strConfig,
} from "@/lib/feed-layout";
import { AdminOnly } from "@/components/AdminOnly";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TAGS = ["Объявление", "Важно", "Новинка", "HR", "Аттестация"];

const LINK_MODES = [
  { value: "none", label: "Без кнопки / ссылки" },
  { value: "auto_test", label: "Первый доступный тест" },
  { value: "test", label: "Конкретный тест" },
  { value: "course", label: "Конкретный курс" },
  { value: "url", label: "Ссылка (путь)" },
];

export const Route = createFileRoute("/_authenticated/admin/feed")({
  component: () => (
    <AdminOnly>
      <AdminFeedAdminPage />
    </AdminOnly>
  ),
});

type FormState = { title: string; body: string; tag: string };

const emptyForm = (): FormState => ({ title: "", body: "", tag: "Объявление" });

function AdminFeedAdminPage() {
  const [tab, setTab] = useState("layout");

  return (
    <div>
      <PageHeader
        title="Управление лентой"
        description="Конструктор блоков ленты, объявления и уведомления сотрудникам"
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="layout" className="gap-2">
            <LayoutTemplate className="h-4 w-4" />
            Конструктор
          </TabsTrigger>
          <TabsTrigger value="announcements" className="gap-2">
            <Megaphone className="h-4 w-4" />
            Объявления
          </TabsTrigger>
        </TabsList>

        <TabsContent value="layout">
          <FeedLayoutBuilder />
        </TabsContent>
        <TabsContent value="announcements">
          <AnnouncementsPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function FeedLayoutBuilder() {
  const qc = useQueryClient();
  const [titleTemplate, setTitleTemplate] = useState("Добрый день, {name}");
  const [pageDescription, setPageDescription] = useState("");
  const [blocks, setBlocks] = useState<FeedBlock[]>([]);
  const [addType, setAddType] = useState<FeedBlockType>("custom");
  const [dirty, setDirty] = useState(false);

  const { data: layout, isLoading } = useQuery({
    queryKey: ["admin-feed-layout"],
    queryFn: () => adminApi.feedLayout.get(),
  });

  const { data: tests } = useQuery({
    queryKey: ["tests"],
    queryFn: () => testsApi.list(),
  });

  const { data: courses } = useQuery({
    queryKey: ["courses"],
    queryFn: () => coursesApi.list(),
  });

  useEffect(() => {
    if (!layout) return;
    setTitleTemplate(layout.title_template);
    setPageDescription(layout.page_description ?? "");
    setBlocks(layout.blocks as FeedBlock[]);
    setDirty(false);
  }, [layout]);

  const save = useMutation({
    mutationFn: () =>
      adminApi.feedLayout.update({
        title_template: titleTemplate,
        page_description: pageDescription || null,
        blocks,
      }),
    onSuccess: () => {
      toast.success("Лента сохранена");
      setDirty(false);
      qc.invalidateQueries({ queryKey: ["admin-feed-layout"] });
      qc.invalidateQueries({ queryKey: ["feed"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Ошибка сохранения"),
  });

  const patchBlock = (id: string, patch: Partial<FeedBlock>) => {
    setBlocks((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)));
    setDirty(true);
  };

  const patchConfig = (id: string, key: string, value: unknown) => {
    setBlocks((prev) =>
      prev.map((b) =>
        b.id === id ? { ...b, config: { ...b.config, [key]: value } } : b,
      ),
    );
    setDirty(true);
  };

  const moveBlock = (index: number, dir: -1 | 1) => {
    const next = index + dir;
    if (next < 0 || next >= blocks.length) return;
    setBlocks((prev) => {
      const copy = [...prev];
      [copy[index], copy[next]] = [copy[next], copy[index]];
      return copy;
    });
    setDirty(true);
  };

  const removeBlock = (id: string) => {
    if (!confirm("Удалить блок из ленты?")) return;
    setBlocks((prev) => prev.filter((b) => b.id !== id));
    setDirty(true);
  };

  const addBlock = () => {
    setBlocks((prev) => [...prev, newFeedBlock(addType)]);
    setDirty(true);
  };

  if (isLoading) {
    return <Card className="p-12 animate-pulse h-40 bg-muted/40" />;
  }

  return (
    <div className="space-y-6">
      <Card className="p-5 space-y-4">
        <h3 className="font-display font-semibold">Заголовок страницы</h3>
        <div>
          <Label>Шаблон приветствия</Label>
          <Input
            value={titleTemplate}
            onChange={(e) => {
              setTitleTemplate(e.target.value);
              setDirty(true);
            }}
            placeholder="Добрый день, {name}"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Используйте {"{name}"} — подставится имя пользователя
          </p>
        </div>
        <div>
          <Label>Описание под заголовком</Label>
          <Textarea
            rows={2}
            value={pageDescription}
            onChange={(e) => {
              setPageDescription(e.target.value);
              setDirty(true);
            }}
          />
        </div>
      </Card>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h3 className="font-display font-semibold text-lg">Блоки ленты</h3>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={addType} onValueChange={(v) => setAddType(v as FeedBlockType)}>
            <SelectTrigger className="w-[220px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(BLOCK_LABELS) as FeedBlockType[]).map((t) => (
                <SelectItem key={t} value={t}>
                  {BLOCK_LABELS[t]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2" onClick={addBlock}>
            <Plus className="h-4 w-4" />
            Добавить
          </Button>
          <Button
            className="gap-2"
            disabled={!dirty || save.isPending}
            onClick={() => save.mutate()}
          >
            <Save className="h-4 w-4" />
            Сохранить ленту
          </Button>
        </div>
      </div>

      {blocks.length === 0 ? (
        <Card className="p-10 text-center text-muted-foreground">
          Нет блоков. Добавьте первый блок или сохраните настройки по умолчанию.
        </Card>
      ) : (
        <ul className="space-y-4">
          {blocks.map((block, index) => (
            <Card key={block.id} className="p-5">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-4">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">{BLOCK_LABELS[block.type as FeedBlockType] ?? block.type}</Badge>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={block.enabled}
                      onCheckedChange={(enabled) => patchBlock(block.id, { enabled })}
                    />
                    <span className="text-sm text-muted-foreground">
                      {block.enabled ? "Включён" : "Скрыт"}
                    </span>
                  </div>
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button
                    size="icon"
                    variant="outline"
                    disabled={index === 0}
                    onClick={() => moveBlock(index, -1)}
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    disabled={index === blocks.length - 1}
                    onClick={() => moveBlock(index, 1)}
                  >
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    className="text-destructive"
                    onClick={() => removeBlock(block.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <BlockEditor
                block={block}
                tests={tests ?? []}
                courses={courses ?? []}
                onConfig={patchConfig}
              />
            </Card>
          ))}
        </ul>
      )}
    </div>
  );
}

function BlockEditor({
  block,
  tests,
  courses,
  onConfig,
}: {
  block: FeedBlock;
  tests: { id: string; title: string }[];
  courses: { id: string; title: string }[];
  onConfig: (id: string, key: string, value: unknown) => void;
}) {
  const cfg = block.config;
  const set = (key: string, value: unknown) => onConfig(block.id, key, value);

  const linkFields = (showButton = true) => (
    <>
      {showButton && (
        <div>
          <Label>Текст кнопки</Label>
          <Input
            value={strConfig(cfg, "button_text")}
            onChange={(e) => set("button_text", e.target.value)}
          />
        </div>
      )}
      <div>
        <Label>Куда ведёт кнопка</Label>
        <Select
          value={strConfig(cfg, "link_mode", "none")}
          onValueChange={(v) => set("link_mode", v)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {LINK_MODES.map((m) => (
              <SelectItem key={m.value} value={m.value}>
                {m.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {strConfig(cfg, "link_mode") === "test" && (
        <div>
          <Label>Тест</Label>
          <Select value={strConfig(cfg, "test_id")} onValueChange={(v) => set("test_id", v)}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите тест" />
            </SelectTrigger>
            <SelectContent>
              {tests.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  {t.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      {strConfig(cfg, "link_mode") === "course" && (
        <div>
          <Label>Курс</Label>
          <Select value={strConfig(cfg, "course_id")} onValueChange={(v) => set("course_id", v)}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите курс" />
            </SelectTrigger>
            <SelectContent>
              {courses.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      {strConfig(cfg, "link_mode") === "url" && (
        <div>
          <Label>Путь (например /tests или /courses)</Label>
          <Input
            value={strConfig(cfg, "url", "/tests")}
            onChange={(e) => set("url", e.target.value)}
          />
        </div>
      )}
    </>
  );

  switch (block.type) {
    case "hero":
      return (
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label>Метка</Label>
            <Input value={strConfig(cfg, "badge")} onChange={(e) => set("badge", e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <Label>Заголовок</Label>
            <Input value={strConfig(cfg, "title")} onChange={(e) => set("title", e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <Label>Текст</Label>
            <Textarea
              rows={3}
              value={strConfig(cfg, "body")}
              onChange={(e) => set("body", e.target.value)}
            />
          </div>
          {linkFields()}
        </div>
      );
    case "stats":
      return (
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label>Подпись: курсы</Label>
            <Input
              value={strConfig(cfg, "label_courses")}
              onChange={(e) => set("label_courses", e.target.value)}
            />
          </div>
          <div>
            <Label>Подпись: тесты</Label>
            <Input
              value={strConfig(cfg, "label_tests")}
              onChange={(e) => set("label_tests", e.target.value)}
            />
          </div>
          <div>
            <Label>Подпись: успешные</Label>
            <Input
              value={strConfig(cfg, "label_passed")}
              onChange={(e) => set("label_passed", e.target.value)}
            />
          </div>
        </div>
      );
    case "announcements":
      return (
        <div>
          <Label>Заголовок секции</Label>
          <Input
            value={strConfig(cfg, "title", "Объявления")}
            onChange={(e) => set("title", e.target.value)}
          />
          <p className="text-xs text-muted-foreground mt-2">
            Содержимое — во вкладке «Объявления»
          </p>
        </div>
      );
    case "continue_courses":
    case "new_courses":
    case "tests":
    case "recent_activity":
      return (
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label>Заголовок секции</Label>
            <Input value={strConfig(cfg, "title")} onChange={(e) => set("title", e.target.value)} />
          </div>
          <div>
            <Label>Макс. элементов</Label>
            <Input
              type="number"
              min={1}
              max={20}
              value={numConfig(cfg, "max_items", 4)}
              onChange={(e) => set("max_items", Number(e.target.value))}
            />
          </div>
        </div>
      );
    case "custom":
      return (
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label>Метка (необязательно)</Label>
            <Input value={strConfig(cfg, "badge")} onChange={(e) => set("badge", e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <Label>Заголовок</Label>
            <Input value={strConfig(cfg, "title")} onChange={(e) => set("title", e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <Label>Текст</Label>
            <Textarea
              rows={4}
              value={strConfig(cfg, "body")}
              onChange={(e) => set("body", e.target.value)}
            />
          </div>
          {linkFields()}
        </div>
      );
    default:
      return null;
  }
}

function AnnouncementsPanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Announcement | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());

  const { data, isLoading } = useQuery({
    queryKey: ["admin-announcements"],
    queryFn: () => adminApi.announcements.list(),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    qc.invalidateQueries({ queryKey: ["feed"] });
  };

  const openCreate = () => {
    setEdit(null);
    setForm(emptyForm());
    setOpen(true);
  };

  const openEdit = (a: Announcement) => {
    setEdit(a);
    setForm({ title: a.title, body: a.body, tag: a.tag });
    setOpen(true);
  };

  const save = async () => {
    if (!form.title.trim() || !form.body.trim()) {
      toast.error("Заполните заголовок и текст");
      return;
    }
    try {
      if (edit) {
        await adminApi.announcements.update(edit.id, form);
        toast.success("Объявление обновлено");
      } else {
        await adminApi.announcements.create(form);
        toast.success("Объявление создано");
      }
      setOpen(false);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const publish = async (id: string) => {
    try {
      const res = await adminApi.announcements.publish(id);
      toast.success(`Опубликовано. Уведомлений отправлено: ${res.notifications_sent}`);
      invalidate();
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["notifications-unread-count"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const resend = async (id: string) => {
    if (!confirm("Отправить уведомление всем пользователям повторно?")) return;
    try {
      const res = await adminApi.announcements.notify(id);
      toast.success(`Отправлено уведомлений: ${res.notifications_sent}`);
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["notifications-unread-count"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const remove = async (id: string, title: string) => {
    if (!confirm(`Удалить объявление «${title}»?`)) return;
    try {
      await adminApi.announcements.delete(id);
      toast.success("Удалено");
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  return (
    <div>
      <div className="flex justify-end mb-4">
        <Button className="gap-2" onClick={openCreate}>
          <Plus className="h-4 w-4" />
          Новое объявление
        </Button>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{edit ? "Редактировать объявление" : "Новое объявление"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Заголовок</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div>
              <Label>Текст</Label>
              <Textarea
                rows={5}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
              />
            </div>
            <div>
              <Label>Метка</Label>
              <Select value={form.tag} onValueChange={(tag) => setForm({ ...form, tag })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TAGS.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Отмена
            </Button>
            <Button onClick={save}>{edit ? "Сохранить" : "Создать черновик"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {isLoading ? (
        <Card className="p-12 animate-pulse h-40 bg-muted/40" />
      ) : !data || data.length === 0 ? (
        <Card className="p-12 text-center text-muted-foreground">
          <Megaphone className="h-8 w-8 mx-auto mb-2" />
          Нет объявлений. Создайте первое — оно появится на ленте после публикации.
        </Card>
      ) : (
        <ul className="space-y-4">
          {data.map((a) => (
            <Card key={a.id} className="p-5">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge variant="secondary">{a.tag}</Badge>
                    {a.is_published ? (
                      <Badge className="bg-success text-success-foreground">На ленте</Badge>
                    ) : (
                      <Badge variant="outline">Черновик</Badge>
                    )}
                  </div>
                  <h3 className="font-display font-semibold text-lg">{a.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{a.body}</p>
                  {a.published_at && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      Опубликовано: {new Date(a.published_at).toLocaleString("ru-RU")}
                    </p>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 shrink-0">
                  <Button size="sm" variant="outline" onClick={() => openEdit(a)}>
                    <Pencil className="h-4 w-4 mr-1" />
                    Изменить
                  </Button>
                  {!a.is_published ? (
                    <Button size="sm" className="gap-1" onClick={() => publish(a.id)}>
                      <Send className="h-4 w-4" />
                      Опубликовать и уведомить
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="secondary"
                      className="gap-1"
                      onClick={() => resend(a.id)}
                    >
                      <Send className="h-4 w-4" />
                      Уведомить снова
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-destructive"
                    onClick={() => remove(a.id, a.title)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </ul>
      )}
    </div>
  );
}
