import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { testsApi, type Question } from "@/lib/api";
import { QUESTION_TYPE_LABELS, type QuestionType } from "@/lib/test-utils";
import { AdminOnly } from "@/components/AdminOnly";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  QuestionFormDialog,
  type QuestionDraft,
} from "@/components/admin/QuestionFormDialog";

export const Route = createFileRoute("/_authenticated/admin/tests/$id")({
  component: () => (
    <AdminOnly>
      <AdminTestEditorPage />
    </AdminOnly>
  ),
});

function AdminTestEditorPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [qDialogOpen, setQDialogOpen] = useState(false);
  const [editingQ, setEditingQ] = useState<QuestionDraft | null>(null);
  const [meta, setMeta] = useState<{
    title: string;
    description: string;
    duration_minutes: number;
    passing_score: number;
    max_attempts: number;
  } | null>(null);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["admin-test", id],
    queryFn: () => testsApi.get(id),
  });

  useEffect(() => {
    if (data) {
      setMeta({
        title: data.title,
        description: data.description ?? "",
        duration_minutes: data.duration_minutes,
        passing_score: data.passing_score,
        max_attempts: data.max_attempts,
      });
    }
  }, [
    data?.id,
    data?.title,
    data?.description,
    data?.duration_minutes,
    data?.passing_score,
    data?.max_attempts,
  ]);

  const saveMeta = async () => {
    if (!meta) return;
    try {
      await testsApi.update(id, {
        title: meta.title,
        description: meta.description || undefined,
        duration_minutes: meta.duration_minutes,
        passing_score: meta.passing_score,
        max_attempts: meta.max_attempts,
      });
      toast.success("Настройки теста сохранены");
      qc.invalidateQueries({ queryKey: ["admin-test", id] });
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const togglePublish = async () => {
    if (!data) return;
    try {
      await testsApi.update(id, { is_published: !data.is_published });
      toast.success(data.is_published ? "Снято с публикации" : "Опубликовано");
      refetch();
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const deleteQuestion = async (qId: string) => {
    if (!confirm("Удалить вопрос?")) return;
    try {
      await testsApi.deleteQuestion(id, qId);
      toast.success("Вопрос удалён");
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const removeTest = async () => {
    if (!data) return;
    if (
      !confirm(
        `Удалить тест «${data.title}»?\n\nВсе вопросы и попытки будут удалены безвозвратно.`,
      )
    ) {
      return;
    }
    try {
      await testsApi.delete(id);
      toast.success("Тест удалён");
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
      qc.invalidateQueries({ queryKey: ["tests-published"] });
      navigate({ to: "/admin/tests" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const openEdit = (q: Question) => {
    setEditingQ({
      id: q.id,
      question_text: q.question_text,
      question_type: q.question_type as QuestionType,
      points: q.points,
      position: q.position,
      answer_options: q.answer_options.map((o) => ({
        answer_text: o.answer_text,
        is_correct: o.is_correct,
        position: o.position,
      })),
    });
    setQDialogOpen(true);
  };

  const openNew = () => {
    setEditingQ(null);
    setQDialogOpen(true);
  };

  if (isLoading || !data || !meta) {
    return (
      <div className="py-12 text-center text-muted-foreground">Загрузка редактора…</div>
    );
  }

  const questions = [...data.questions].sort((a, b) => a.position - b.position);

  return (
    <div>
      <PageHeader
        title={data.title}
        description="Настройки теста и конструктор вопросов с вариантами ответов"
        actions={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={togglePublish}>
              {data.is_published ? "Снять с публикации" : "Опубликовать"}
            </Button>
            <Button
              variant="outline"
              className="text-destructive hover:text-destructive"
              onClick={removeTest}
            >
              <Trash2 className="h-4 w-4 mr-1.5" />
              Удалить тест
            </Button>
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-1 h-fit space-y-4">
          <h2 className="font-display font-semibold">Параметры</h2>
          <div>
            <Label>Название</Label>
            <Input value={meta.title} onChange={(e) => setMeta({ ...meta, title: e.target.value })} />
          </div>
          <div>
            <Label>Описание</Label>
            <Textarea
              value={meta.description}
              onChange={(e) => setMeta({ ...meta, description: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Время (мин)</Label>
              <Input
                type="number"
                min={1}
                value={meta.duration_minutes}
                onChange={(e) =>
                  setMeta({ ...meta, duration_minutes: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <Label>Проходной %</Label>
              <Input
                type="number"
                min={1}
                max={100}
                value={meta.passing_score}
                onChange={(e) => setMeta({ ...meta, passing_score: Number(e.target.value) })}
              />
            </div>
            <div className="col-span-2">
              <Label>Лимит попыток (0 = без лимита)</Label>
              <Input
                type="number"
                min={0}
                value={meta.max_attempts}
                onChange={(e) => setMeta({ ...meta, max_attempts: Number(e.target.value) })}
              />
            </div>
          </div>
          <Button className="w-full" onClick={saveMeta}>
            Сохранить параметры
          </Button>
          <Button
            variant="outline"
            className="w-full text-destructive hover:text-destructive"
            onClick={removeTest}
          >
            <Trash2 className="h-4 w-4 mr-1.5" />
            Удалить тест
          </Button>
          {data.is_published ? (
            <Badge className="bg-success text-success-foreground">Опубликован</Badge>
          ) : (
            <Badge variant="secondary">Черновик</Badge>
          )}
        </Card>

        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold">
              Вопросы ({questions.length})
            </h2>
            <Button size="sm" className="gap-1" onClick={openNew}>
              <Plus className="h-4 w-4" /> Добавить
            </Button>
          </div>

          {questions.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">
              Добавьте первый вопрос — выберите тип и варианты ответов.
            </p>
          ) : (
            <ul className="space-y-3">
              {questions.map((q, i) => (
                <li
                  key={q.id}
                  className="rounded-lg border border-border p-4 flex flex-col sm:flex-row sm:items-start gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="text-xs text-muted-foreground">#{i + 1}</span>
                      <Badge variant="outline" className="text-xs">
                        {QUESTION_TYPE_LABELS[q.question_type as QuestionType] ??
                          q.question_type}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{q.points} б.</span>
                    </div>
                    <p className="text-sm font-medium">{q.question_text}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {q.answer_options.length} вариант(ов)
                    </p>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="icon" variant="outline" onClick={() => openEdit(q)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="text-destructive"
                      onClick={() => deleteQuestion(q.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <QuestionFormDialog
        testId={id}
        open={qDialogOpen}
        onOpenChange={setQDialogOpen}
        initial={editingQ}
        nextPosition={questions.length}
        onSaved={() => refetch()}
      />
    </div>
  );
}
