import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Award, BookOpen, Clock, Target, TrendingUp } from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useAuth } from "@/lib/auth-context";
import { coursesApi, testsApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/EmptyState";
import { PageHeader } from "@/components/AppShell";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const { profile } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ["my-stats"],
    queryFn: async () => {
      const arr = await testsApi.myAttempts();
      const completed = arr.filter((a) => a.completed_at);
      const passed = completed.filter((a) => a.passed).length;
      const avg = completed.length
        ? completed.reduce((s, a) => s + Number(a.score ?? 0), 0) / completed.length
        : 0;
      return { total: completed.length, passed, avg, items: completed };
    },
  });

  const { data: myCourses } = useQuery({
    queryKey: ["my-courses"],
    queryFn: () => coursesApi.myCourses(),
  });

  const chartData = (stats?.items ?? []).slice(-8).map((a, i) => ({
    name: `#${i + 1}`,
    score: Number(a.score ?? 0),
  }));

  return (
    <div>
      <PageHeader
        title="Мой кабинет"
        description={`Статистика и прогресс — ${profile?.full_name ?? profile?.email ?? ""}`}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={BookOpen} label="Пройдено тестов" value={stats?.total ?? 0} />
        <StatCard
          icon={Target}
          label="Средний балл"
          value={`${(stats?.avg ?? 0).toFixed(1)}%`}
          accent="text-primary"
        />
        <StatCard icon={Award} label="Успешных" value={stats?.passed ?? 0} accent="text-success" />
        <StatCard
          icon={TrendingUp}
          label="Динамика"
          value={stats && stats.items.length > 1 ? "↑" : "—"}
          accent="text-success"
        />
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Динамика результатов</h2>
            <span className="text-xs text-muted-foreground">последние 8 попыток</span>
          </div>
          <div className="mt-4 h-64">
            {chartData.length === 0 ? (
              <EmptyState
                icon={Clock}
                title="Пока нет данных"
                description="Пройдите первый тест, чтобы увидеть динамику"
              />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="var(--primary)"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-lg font-semibold">Мои курсы</h2>
          <div className="mt-5 space-y-5">
            {!myCourses || myCourses.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Вы ещё не записались на курс.{" "}
                <Link to="/courses" className="text-primary hover:underline">
                  Смотреть каталог
                </Link>
              </p>
            ) : (
              myCourses.slice(0, 4).map((c) => (
                <div key={c.id}>
                  <div className="flex justify-between text-sm">
                    <span className="line-clamp-1">{c.title}</span>
                    <span className="text-muted-foreground shrink-0 ml-2">{c.progress}%</span>
                  </div>
                  <Progress value={c.progress} className="mt-2" />
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
  accent?: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        <span className="text-xs">{label}</span>
      </div>
      <div className={"mt-3 font-display text-3xl font-semibold " + (accent ?? "")}>{value}</div>
    </Card>
  );
}
