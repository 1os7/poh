import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { coursesApi, testsApi } from "@/lib/api";
import { AdminOnly } from "@/components/AdminOnly";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RouteLinkButton } from "@/components/RouteLinkButton";

export const Route = createFileRoute("/_authenticated/admin/courses/$id")({
  component: () => (
    <AdminOnly>
      <AdminCourseEditorPage />
    </AdminOnly>
  ),
});

function AdminCourseEditorPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const [meta, setMeta] = useState<{
    title: string;
    description: string;
    passing_score: number;
  } | null>(null);
  const [lessonOpen, setLessonOpen] = useState(false);
  const [lessonForm, setLessonForm] = useState({
    id: "" as string | null,
    title: "",
    content: "",
    video_url: "",
  });

  const { data: course, refetch: refetchCourse } = useQuery({
    queryKey: ["admin-course", id],
    queryFn: () => coursesApi.get(id),
  });

  const { data: lessons, refetch: refetchLessons } = useQuery({
    queryKey: ["admin-course-lessons", id],
    queryFn: () => coursesApi.listLessons(id),
  });

  const { data: allTests } = useQuery({
    queryKey: ["admin-tests"],
    queryFn: () => testsApi.list(),
  });

  useEffect(() => {
    if (course) {
      setMeta({
        title: course.title,
        description: course.description ?? "",
        passing_score: course.passing_score ?? 70,
      });
    }
  }, [course?.id, course?.title, course?.description, course?.passing_score]);

  const linkedTests = (allTests ?? []).filter((t) => t.course_id === id);
  const finalTest = linkedTests[0];

  const saveMeta = async () => {
    if (!meta) return;
    try {
      await coursesApi.update(id, {
        title: meta.title,
        description: meta.description || undefined,
        passing_score: meta.passing_score,
      });
      toast.success("Курс сохранён");
      refetchCourse();
      qc.invalidateQueries({ queryKey: ["admin-courses"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const togglePublish = async () => {
    if (!course) return;
    try {
      await coursesApi.update(id, { is_published: !course.is_published });
      toast.success(course.is_published ? "Снято" : "Опубликовано");
      refetchCourse();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const openLesson = (lesson?: { id: string; title: string; content: string | null; video_url: string | null }) => {
    if (lesson) {
      setLessonForm({
        id: lesson.id,
        title: lesson.title,
        content: lesson.content ?? "",
        video_url: lesson.video_url ?? "",
      });
    } else {
      setLessonForm({ id: null, title: "", content: "", video_url: "" });
    }
    setLessonOpen(true);
  };

  const saveLesson = async () => {
    if (!lessonForm.title.trim()) return toast.error("Название урока обязательно");
    try {
      if (lessonForm.id) {
        await coursesApi.updateLesson(id, lessonForm.id, {
          title: lessonForm.title,
          content: lessonForm.content || undefined,
          video_url: lessonForm.video_url || undefined,
        });
        toast.success("Урок обновлён");
      } else {
        await coursesApi.createLesson(id, {
          title: lessonForm.title,
          content: lessonForm.content || undefined,
          video_url: lessonForm.video_url || undefined,
          position: lessons?.length ?? 0,
        });
        toast.success("Урок добавлен");
      }
      setLessonOpen(false);
      refetchLessons();
      refetchCourse();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const deleteLesson = async (lessonId: string) => {
    if (!confirm("Удалить урок?")) return;
    try {
      await coursesApi.deleteLesson(id, lessonId);
      toast.success("Урок удалён");
      refetchLessons();
      refetchCourse();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const linkTest = async (testId: string) => {
    try {
      for (const t of linkedTests) {
        if (t.id !== testId) {
          await testsApi.update(t.id, { course_id: undefined });
        }
      }
      await testsApi.update(testId, { course_id: id });
      toast.success("Итоговый тест привязан");
      qc.invalidateQueries({ queryKey: ["admin-tests"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    }
  };

  if (!course || !meta) {
    return <div className="py-12 text-center text-muted-foreground">Загрузка…</div>;
  }

  const sortedLessons = [...(lessons ?? [])].sort((a, b) => a.position - b.position);

  return (
    <div>
      <PageHeader
        title={course.title}
        description="Уроки с HTML-материалами и привязка итогового теста"
        actions={
          <Button variant="outline" onClick={togglePublish}>
            {course.is_published ? "Снять с публикации" : "Опубликовать"}
          </Button>
        }
      />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-1 h-fit space-y-4">
          <h2 className="font-display font-semibold">Параметры курса</h2>
          <div>
            <Label>Название</Label>
            <Input value={meta.title} onChange={(e) => setMeta({ ...meta, title: e.target.value })} />
          </div>
          <div>
            <Label>Описание</Label>
            <Textarea
              value={meta.description}
              onChange={(e) => setMeta({ ...meta, description: e.target.value })}
            />
          </div>
          <div>
            <Label>Проходной балл (%)</Label>
            <Input
              type="number"
              min={1}
              max={100}
              value={meta.passing_score}
              onChange={(e) => setMeta({ ...meta, passing_score: Number(e.target.value) })}
            />
          </div>
          <Button className="w-full" onClick={saveMeta}>
            Сохранить
          </Button>

          <div className="pt-4 border-t border-border">
            <h3 className="text-sm font-medium mb-2">Итоговый тест</h3>
            {finalTest ? (
              <div className="space-y-2">
                <p className="text-sm">{finalTest.title}</p>
                <RouteLinkButton
                  to="/admin/tests/$id"
                  params={{ id: finalTest.id }}
                  size="sm"
                  variant="outline"
                  className="w-full"
                >
                  Редактировать тест
                </RouteLinkButton>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground mb-2">
                Привяжите существующий тест или создайте новый в разделе «Тесты».
              </p>
            )}
            <Select
              value={finalTest?.id ?? ""}
              onValueChange={(v) => v && linkTest(v)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Привязать тест…" />
              </SelectTrigger>
              <SelectContent>
                {(allTests ?? []).map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-display font-semibold">Уроки ({sortedLessons.length})</h2>
            <Button size="sm" className="gap-1" onClick={() => openLesson()}>
              <Plus className="h-4 w-4" /> Урок
            </Button>
          </div>

          {sortedLessons.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              Добавьте уроки с HTML-контентом и ссылкой на видео.
            </p>
          ) : (
            <ul className="space-y-2">
              {sortedLessons.map((l, i) => (
                <li
                  key={l.id}
                  className="flex items-center gap-3 rounded-lg border border-border p-3"
                >
                  <span className="text-xs text-muted-foreground w-6">{i + 1}.</span>
                  <span className="flex-1 text-sm font-medium truncate">{l.title}</span>
                  <Button size="icon" variant="ghost" onClick={() => openLesson(l)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => deleteLesson(l.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Dialog open={lessonOpen} onOpenChange={setLessonOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{lessonForm.id ? "Редактировать урок" : "Новый урок"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Название</Label>
              <Input
                value={lessonForm.title}
                onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
              />
            </div>
            <div>
              <Label>Ссылка на видео (необязательно)</Label>
              <Input
                value={lessonForm.video_url}
                onChange={(e) => setLessonForm({ ...lessonForm, video_url: e.target.value })}
                placeholder="https://…"
              />
            </div>
            <div>
              <Label>Содержание (HTML)</Label>
              <Textarea
                rows={8}
                value={lessonForm.content}
                onChange={(e) => setLessonForm({ ...lessonForm, content: e.target.value })}
                placeholder="<p>Текст урока…</p>"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLessonOpen(false)}>
              Отмена
            </Button>
            <Button onClick={saveLesson}>Сохранить</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
