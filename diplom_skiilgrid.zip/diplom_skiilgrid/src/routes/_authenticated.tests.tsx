import { createFileRoute, Outlet } from "@tanstack/react-router";

/** Layout: дочерние маршруты /tests/$id рендерятся через Outlet */
export const Route = createFileRoute("/_authenticated/tests")({
  component: () => <Outlet />,
});
