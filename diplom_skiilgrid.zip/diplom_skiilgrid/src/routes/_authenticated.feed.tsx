import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { feedApi, notificationsApi } from "@/lib/api";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { FeedRenderer } from "@/components/feed/FeedRenderer";

type FeedSearch = { highlight?: string };

export const Route = createFileRoute("/_authenticated/feed")({
  validateSearch: (search: Record<string, unknown>): FeedSearch => ({
    highlight: typeof search.highlight === "string" ? search.highlight : undefined,
  }),
  component: FeedPage,
});

function FeedPage() {
  const { highlight: highlightId } = Route.useSearch();
  const qc = useQueryClient();
  const highlightRef = useRef<HTMLDivElement | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["feed"],
    queryFn: () => feedApi.get(),
  });

  const markReadByAnnouncement = useMutation({
    mutationFn: async (announcementId: string) => {
      const list = await notificationsApi.list(true);
      const match = list.find((n) => n.announcement_id === announcementId);
      if (match) await notificationsApi.markRead(match.id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["feed"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["notifications-unread-count"] });
    },
  });

  useEffect(() => {
    if (!highlightId || !data) return;
    highlightRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    const item = data.highlights.find((h) => h.id === highlightId);
    if (item && !item.is_read) {
      markReadByAnnouncement.mutate(highlightId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [highlightId, data?.highlights.length]);

  const layout = data?.layout;
  const blocks = layout?.blocks ?? [];

  return (
    <div className="space-y-8">
      <PageHeader
        title={data?.greeting ?? "Лента"}
        description={
          layout?.page_description ??
          "Проверка компетенций: курсы для обучения, тесты для аттестации"
        }
      />

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="h-28 animate-pulse bg-muted/40" />
          ))}
        </div>
      ) : data ? (
        <FeedRenderer
          blocks={blocks}
          data={data}
          highlightId={highlightId}
          onMarkRead={(id) => markReadByAnnouncement.mutate(id)}
          highlightRef={highlightRef}
        />
      ) : null}
    </div>
  );
}
