import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, CheckCircle2, Clock, Search, Target } from "lucide-react";
import { useState } from "react";
import { testsApi } from "@/lib/api";
import { PageHeader } from "@/components/AppShell";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/EmptyState";
import { QueryError } from "@/components/QueryError";
import { RouteLinkButton } from "@/components/RouteLinkButton";

export const Route = createFileRoute("/_authenticated/tests/")({
  component: TestsPage,
});

function TestsPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["tests-published"],
    queryFn: () => testsApi.list(),
  });

  const filtered = (data ?? []).filter(
    (t) => !q || t.title.toLowerCase().includes(q.toLowerCase()),
  );

  const firstOpen = filtered.find((t) => !t.user_passed);

  if (isError) {
    return (
      <div>
        <PageHeader title="Проверка компетенций" description="Тесты для оценки знаний и навыков" />
        <QueryError
          message={error instanceof Error ? error.message : "Ошибка"}
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Проверка компетенций"
        description="Один ответ, несколько, текст, порядок — результат сохраняется в истории"
        actions={
          firstOpen ? (
            <RouteLinkButton to="/tests/$id" params={{ id: firstOpen.id }} className="gap-2">
              <Target className="h-4 w-4" />
              Начать аттестацию
            </RouteLinkButton>
          ) : undefined
        }
      />

      <div className="mb-5 relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Поиск по тестам…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="p-6 animate-pulse h-44 bg-muted/40" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12">
          <EmptyState
            icon={BookOpen}
            title="Пока нет доступных тестов"
            description="Администратор ещё не опубликовал тесты"
          />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((t) => (
            <Card
              key={t.id}
              role="button"
              tabIndex={0}
              className={
                "p-6 flex flex-col hover:shadow-elevated transition cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring " +
                (t.user_passed ? "ring-1 ring-success/30" : "")
              }
              onClick={() => navigate({ to: "/tests/$id", params: { id: t.id } })}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  navigate({ to: "/tests/$id", params: { id: t.id } });
                }
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div
                  className={
                    "grid h-10 w-10 place-items-center rounded-lg " +
                    (t.user_passed
                      ? "bg-success/10 text-success"
                      : "bg-primary-soft text-primary")
                  }
                >
                  {t.user_passed ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : (
                    <BookOpen className="h-5 w-5" />
                  )}
                </div>
                {t.user_passed ? (
                  <Badge className="bg-success text-success-foreground text-xs shrink-0">
                    Пройден
                    {t.user_best_score != null ? ` · ${t.user_best_score.toFixed(0)}%` : ""}
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="text-xs shrink-0">
                    Проходной {t.passing_score}%
                  </Badge>
                )}
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{t.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2 flex-1">
                {t.description ?? "Без описания"}
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" /> {t.duration_minutes} мин
                </span>
                <span>{t.question_count ?? 0} вопросов</span>
                {t.max_attempts > 0 && (
                  <span>
                    попыток: {t.user_attempts ?? 0}/{t.max_attempts}
                  </span>
                )}
              </div>
              <div className="mt-4" onClick={(e) => e.stopPropagation()}>
                {t.can_attempt === false ? (
                  <Button className="w-full" variant="secondary" disabled>
                    Лимит попыток исчерпан
                  </Button>
                ) : (
                  <RouteLinkButton
                    to="/tests/$id"
                    params={{ id: t.id }}
                    className="w-full"
                    variant={t.user_passed ? "outline" : "default"}
                  >
                    {t.user_passed ? "Пройти снова" : "Начать тест"}
                  </RouteLinkButton>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
