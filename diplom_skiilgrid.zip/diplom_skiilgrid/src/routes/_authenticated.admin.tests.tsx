import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AdminOnly } from "@/components/AdminOnly";

export const Route = createFileRoute("/_authenticated/admin/tests")({
  component: () => (
    <AdminOnly>
      <Outlet />
    </AdminOnly>
  ),
});
