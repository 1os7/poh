import { createFileRoute } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { profileApi } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

const schema = z.object({
  full_name: z.string().min(2).max(80),
  department: z.string().max(80).optional().or(z.literal("")),
  position: z.string().max(80).optional().or(z.literal("")),
});
type Form = z.infer<typeof schema>;

function ProfilePage() {
  const { profile, refresh, isAdmin } = useAuth();
  const { register, handleSubmit, reset, formState } = useForm<Form>({
    resolver: zodResolver(schema),
  });

  useEffect(() => {
    reset({
      full_name: profile?.full_name ?? "",
      department: profile?.department ?? "",
      position: profile?.position ?? "",
    });
  }, [profile, reset]);

  const onSubmit = async (data: Form) => {
    try {
      await profileApi.update({
        full_name: data.full_name,
        department: data.department || undefined,
        position: data.position || undefined,
      });
      toast.success("Профиль сохранён");
      await refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка сохранения");
    }
  };

  const initials = (profile?.full_name ?? profile?.email ?? "U")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="max-w-3xl">
      <PageHeader title="Профиль" description="Управление личной информацией" />
      <Card className="p-6 mb-5 flex items-center gap-5">
        <Avatar className="h-16 w-16">
          <AvatarFallback className="bg-primary-soft text-primary text-xl font-display">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div>
          <div className="font-display text-lg font-semibold">
            {profile?.full_name ?? profile?.email}
          </div>
          <div className="text-sm text-muted-foreground">{profile?.email}</div>
          <div className="mt-1 text-xs text-muted-foreground">
            Роль: {isAdmin ? "Администратор" : "Сотрудник"}
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="grid sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <Label htmlFor="full_name">Имя и фамилия</Label>
            <Input id="full_name" {...register("full_name")} />
          </div>
          <div>
            <Label htmlFor="department">Отдел</Label>
            <Input id="department" {...register("department")} />
          </div>
          <div>
            <Label htmlFor="position">Должность</Label>
            <Input id="position" {...register("position")} />
          </div>
          <div className="sm:col-span-2 flex justify-end">
            <Button type="submit" disabled={formState.isSubmitting}>
              {formState.isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Сохранить
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
