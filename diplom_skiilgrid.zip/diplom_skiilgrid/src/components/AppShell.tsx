import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  ClipboardList,
  GraduationCap,
  Home,
  LayoutDashboard,
  LogOut,
  ScrollText,
  Settings,
  ShieldCheck,
  User as UserIcon,
  Users,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { NotificationsBell } from "@/components/NotificationsBell";

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const employeeNav: NavItem[] = [
  { to: "/feed", label: "Лента", icon: Home },
  { to: "/dashboard", label: "Мой кабинет", icon: LayoutDashboard },
  { to: "/courses", label: "Курсы", icon: GraduationCap },
  { to: "/tests", label: "Аттестация", icon: BookOpen },
  { to: "/history", label: "История", icon: ClipboardList },
  { to: "/profile", label: "Профиль", icon: UserIcon },
];

const adminNav: NavItem[] = [
  { to: "/admin", label: "Обзор", icon: LayoutDashboard },
  { to: "/admin/feed", label: "Лента", icon: Home },
  { to: "/admin/users", label: "Сотрудники", icon: Users },
  { to: "/admin/courses", label: "Курсы", icon: GraduationCap },
  { to: "/admin/tests", label: "Тесты", icon: BookOpen },
  { to: "/admin/analytics", label: "Аналитика", icon: BarChart3 },
  { to: "/admin/audit", label: "Аудит", icon: ScrollText },
];

export function AppShell({ variant }: { variant: "employee" | "admin" }) {
  const { profile, isAdmin, signOut } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const nav = variant === "admin" ? adminNav : employeeNav;

  const initials = (profile?.full_name ?? profile?.email ?? "U")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="hidden md:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar">
        <div className="h-16 flex items-center gap-2 px-5 border-b border-sidebar-border">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-[var(--gradient-primary)] text-white">
            <GraduationCap className="h-4 w-4" />
          </div>
          <span className="font-display font-semibold tracking-tight">Skillgrid</span>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          <div className="px-2 pb-2 text-[11px] uppercase tracking-wider text-muted-foreground">
            {variant === "admin" ? "Администрирование" : "Кабинет"}
          </div>
          {nav.map((item) => {
            const active =
              pathname === item.to ||
              (item.to !== "/admin" &&
                item.to !== "/feed" &&
                item.to !== "/dashboard" &&
                pathname.startsWith(item.to));
            return (
              <Link
                key={item.to}
                to={item.to}
                className={
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition " +
                  (active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground")
                }
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
          {isAdmin && variant === "employee" && (
            <Link
              to="/admin"
              className="mt-4 flex items-center gap-2.5 rounded-lg border border-dashed border-border px-3 py-2 text-sm text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
            >
              <ShieldCheck className="h-4 w-4" />
              Админ-панель
            </Link>
          )}
          {variant === "admin" && (
            <Link
              to="/feed"
              className="mt-4 flex items-center gap-2.5 rounded-lg border border-dashed border-border px-3 py-2 text-sm text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
            >
              <UserIcon className="h-4 w-4" />
              Лента сотрудника
            </Link>
          )}
        </nav>
        <div className="p-3 text-xs text-muted-foreground border-t border-sidebar-border">
          <Settings className="inline h-3.5 w-3.5 mr-1.5" />
          v1.0 · Skillgrid
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-border bg-background/80 backdrop-blur px-6">
          <div className="text-sm text-muted-foreground">
            {variant === "admin" ? "Администратор" : "Сотрудник"} ·{" "}
            <span className="text-foreground font-medium">{profile?.department ?? "Без отдела"}</span>
          </div>
          <div className="flex items-center gap-2">
            <NotificationsBell />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="text-xs bg-primary-soft text-primary">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden sm:inline text-sm font-medium">
                    {profile?.full_name ?? profile?.email}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>{profile?.email}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/profile">
                    <UserIcon className="mr-2 h-4 w-4" /> Профиль
                  </Link>
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem asChild>
                    <Link to="/admin">
                      <ShieldCheck className="mr-2 h-4 w-4" /> Админ-панель
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => signOut()}>
                  <LogOut className="mr-2 h-4 w-4" /> Выйти
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 p-6 md:p-8 max-w-[1400px] w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-2xl md:text-3xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="mt-1.5 text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
