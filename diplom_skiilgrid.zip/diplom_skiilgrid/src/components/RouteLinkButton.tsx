import { Link } from "@tanstack/react-router";
import { Button, type ButtonProps } from "@/components/ui/button";

type Props = Pick<ButtonProps, "variant" | "size" | "className"> & {
  to: LinkProps["to"];
  params?: LinkProps["params"];
  search?: LinkProps["search"];
  children: React.ReactNode;
};

/** Кнопка-ссылка: корректная навигация TanStack Router (без вложенного button в a). */
export function RouteLinkButton({ to, params, search, children, variant, size, className }: Props) {
  return (
    <Button asChild variant={variant} size={size} className={className}>
      <Link to={to} params={params} search={search}>
        {children}
      </Link>
    </Button>
  );
}
