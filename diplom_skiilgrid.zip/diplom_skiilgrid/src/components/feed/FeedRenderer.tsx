import { Link } from "@tanstack/react-router";
import { useRef } from "react";
import {
  BookOpen,
  CheckCircle2,
  Clock,
  GraduationCap,
  Megaphone,
  Sparkles,
  Target,
  XCircle,
} from "lucide-react";
import type { FeedData } from "@/lib/api";
import { numConfig, strConfig } from "@/lib/feed-layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { RouteLinkButton } from "@/components/RouteLinkButton";

type HeroLink =
  | { kind: "none" }
  | { kind: "test"; id: string }
  | { kind: "course"; id: string }
  | { kind: "url"; path: string };

function resolveHeroLink(
  cfg: Record<string, unknown>,
  data: FeedData,
): HeroLink {
  const mode = strConfig(cfg, "link_mode", "auto_test");
  if (mode === "none") return { kind: "none" };
  if (mode === "test") {
    const id = strConfig(cfg, "test_id");
    return id ? { kind: "test", id } : { kind: "none" };
  }
  if (mode === "course") {
    const id = strConfig(cfg, "course_id");
    return id ? { kind: "course", id } : { kind: "none" };
  }
  if (mode === "url") {
    const path = strConfig(cfg, "url", "/");
    return path ? { kind: "url", path } : { kind: "none" };
  }
  if (data.featured_test_id) return { kind: "test", id: data.featured_test_id };
  return { kind: "none" };
}

function HeroButton({
  link,
  label,
  className,
}: {
  link: HeroLink;
  label: string;
  className?: string;
}) {
  if (link.kind === "none") return null;
  if (link.kind === "test") {
    return (
      <RouteLinkButton
        to="/tests/$id"
        params={{ id: link.id }}
        size="lg"
        className={className}
      >
        <Target className="h-4 w-4 mr-2" />
        {label}
      </RouteLinkButton>
    );
  }
  if (link.kind === "course") {
    return (
      <RouteLinkButton
        to="/courses/$id"
        params={{ id: link.id }}
        size="lg"
        className={className}
      >
        {label}
      </RouteLinkButton>
    );
  }
  const path = link.path.startsWith("/") ? link.path : `/${link.path}`;
  return (
    <Button asChild size="lg" className={className}>
      <Link to={path as "/"}>{label}</Link>
    </Button>
  );
}

function SectionHead({ title }: { title: string }) {
  return (
    <div className="mb-4">
      <h2 className="font-display text-lg font-semibold">{title}</h2>
    </div>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  accent?: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 text-muted-foreground text-xs">
        <Icon className="h-4 w-4" />
        {label}
      </div>
      <div className={"mt-2 font-display text-3xl font-semibold " + (accent ?? "")}>{value}</div>
    </Card>
  );
}

export function FeedRenderer({
  blocks,
  data,
  highlightId,
  onMarkRead,
  highlightRef,
}: {
  blocks: Array<{ id: string; type: string; enabled: boolean; config: Record<string, unknown> }>;
  data: FeedData;
  highlightId?: string;
  onMarkRead: (announcementId: string) => void;
  highlightRef: React.RefObject<HTMLDivElement | null>;
}) {
  return (
    <>
      {blocks.filter((b) => b.enabled).map((block) => (
        <FeedBlockView
          key={block.id}
          block={block}
          data={data}
          highlightId={highlightId}
          onMarkRead={onMarkRead}
          highlightRef={highlightRef}
        />
      ))}
    </>
  );
}

function FeedBlockView({
  block,
  data,
  highlightId,
  onMarkRead,
  highlightRef,
}: {
  block: { id: string; type: string; enabled: boolean; config: Record<string, unknown> };
  data: FeedData;
  highlightId?: string;
  onMarkRead: (id: string) => void;
  highlightRef: React.RefObject<HTMLDivElement | null>;
}) {
  const cfg = block.config;
  const max = (key: string, def: number) => numConfig(cfg, key, def);

  switch (block.type) {
    case "hero": {
      const link = resolveHeroLink(cfg, data);
      const body = strConfig(cfg, "body");
      const title = strConfig(cfg, "title");
      if (!title && link.kind === "none") return null;
      return (
        <Card
          className="p-6 md:p-8 border-2 border-primary/20"
          style={{ backgroundImage: "var(--gradient-hero)" }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="max-w-xl">
              {strConfig(cfg, "badge") && (
                <Badge className="mb-3 bg-primary text-primary-foreground">
                  {strConfig(cfg, "badge")}
                </Badge>
              )}
              <h2 className="font-display text-xl md:text-2xl font-semibold">{title}</h2>
              {body && <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{body}</p>}
            </div>
            {strConfig(cfg, "button_text") && (
              <HeroButton
                link={link}
                label={strConfig(cfg, "button_text", "Перейти")}
                className="shrink-0"
              />
            )}
          </div>
        </Card>
      );
    }
    case "stats":
      return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <MiniStat
            icon={GraduationCap}
            label={strConfig(cfg, "label_courses", "Курсов в работе")}
            value={data.stats.courses_enrolled}
          />
          <MiniStat
            icon={BookOpen}
            label={strConfig(cfg, "label_tests", "Тестов пройдено")}
            value={data.stats.tests_completed}
          />
          <MiniStat
            icon={Target}
            label={strConfig(cfg, "label_passed", "Успешных попыток")}
            value={data.stats.tests_passed}
            accent="text-success"
          />
        </div>
      );
    case "announcements": {
      const items = data.highlights;
      if (!items.length) return null;
      return (
        <section>
          <h2 className="font-display text-lg font-semibold flex items-center gap-2 mb-4">
            <Megaphone className="h-5 w-5 text-primary" />
            {strConfig(cfg, "title", "Объявления")}
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {items.map((h) => (
              <Card
                key={h.id}
                ref={h.id === highlightId ? highlightRef : undefined}
                className={
                  "p-5 border-l-4 bg-gradient-to-r from-primary/5 to-transparent " +
                  (h.is_read === false
                    ? "border-l-primary ring-1 ring-primary/20"
                    : "border-l-muted")
                }
              >
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">{h.tag}</Badge>
                  {h.is_read === false && (
                    <Badge className="bg-primary text-primary-foreground text-[10px]">Новое</Badge>
                  )}
                </div>
                <h3 className="font-display font-semibold">{h.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground whitespace-pre-wrap">{h.body}</p>
                {h.is_read === false && (
                  <Button
                    variant="link"
                    size="sm"
                    className="mt-2 h-auto p-0"
                    onClick={() => onMarkRead(h.id)}
                  >
                    Отметить прочитанным
                  </Button>
                )}
              </Card>
            ))}
          </div>
        </section>
      );
    }
    case "continue_courses": {
      const courses = data.continue_courses.slice(0, max("max_items", 3));
      if (!courses.length) return null;
      return (
        <section>
          <SectionHead title={strConfig(cfg, "title", "Продолжить обучение")} />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {courses.map((c) => (
              <Card key={c.id} className="p-5 flex flex-col">
                <div className="flex items-center gap-2 text-primary">
                  <Sparkles className="h-4 w-4" />
                  <span className="text-xs font-medium">В процессе</span>
                </div>
                <h3 className="mt-2 font-display font-semibold line-clamp-2">{c.title}</h3>
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>Прогресс</span>
                    <span>{c.progress}%</span>
                  </div>
                  <Progress value={c.progress} />
                </div>
                <RouteLinkButton
                  to="/courses/$id"
                  params={{ id: c.id }}
                  className="w-full mt-4"
                  size="sm"
                >
                  Продолжить
                </RouteLinkButton>
              </Card>
            ))}
          </div>
        </section>
      );
    }
    case "new_courses": {
      const courses = data.new_courses.slice(0, max("max_items", 4));
      return (
        <section>
          <SectionHead title={strConfig(cfg, "title", "Рекомендуемые курсы")} />
          {courses.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground">
              Вы уже записаны на все опубликованные курсы — отличная работа!
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {courses.map((c) => (
                <Card key={c.id} className="p-5 flex flex-col hover:shadow-elevated transition">
                  <GraduationCap className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-display font-semibold text-sm line-clamp-2">{c.title}</h3>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2 flex-1">
                    {c.lesson_count} уроков
                  </p>
                  <RouteLinkButton
                    to="/courses/$id"
                    params={{ id: c.id }}
                    variant="outline"
                    size="sm"
                    className="w-full mt-3"
                  >
                    Открыть
                  </RouteLinkButton>
                </Card>
              ))}
            </div>
          )}
        </section>
      );
    }
    case "tests": {
      const tests = data.tests_due.slice(0, max("max_items", 4));
      if (!tests.length) return null;
      return (
        <section>
          <SectionHead title={strConfig(cfg, "title", "Тесты к прохождению")} />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {tests.map((t) => (
              <Card key={t.id} className="p-5 flex flex-col">
                <BookOpen className="h-7 w-7 text-primary mb-2" />
                <h3 className="font-display font-semibold text-sm line-clamp-2">{t.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {t.duration_minutes} мин · {t.passing_score}%
                </p>
                <RouteLinkButton
                  to="/tests/$id"
                  params={{ id: t.id }}
                  size="sm"
                  className="w-full mt-3"
                >
                  Начать тест
                </RouteLinkButton>
              </Card>
            ))}
          </div>
        </section>
      );
    }
    case "recent_activity": {
      const attempts = data.recent_attempts.slice(0, max("max_items", 5));
      if (!attempts.length) return null;
      return (
        <section>
          <SectionHead title={strConfig(cfg, "title", "Недавняя активность")} />
          <Card className="divide-y divide-border">
            {attempts.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between gap-4 px-5 py-4 text-sm"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{a.test_title ?? "Тест"}</div>
                  <div className="text-xs text-muted-foreground">
                    {a.completed_at
                      ? new Date(a.completed_at).toLocaleString("ru-RU")
                      : "—"}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-display font-semibold tabular-nums">
                    {a.score != null ? `${Number(a.score).toFixed(0)}%` : "—"}
                  </span>
                  {a.passed ? (
                    <CheckCircle2 className="h-5 w-5 text-success" />
                  ) : (
                    <XCircle className="h-5 w-5 text-destructive" />
                  )}
                </div>
              </div>
            ))}
          </Card>
        </section>
      );
    }
    case "custom": {
      const title = strConfig(cfg, "title");
      const body = strConfig(cfg, "body");
      if (!title && !body) return null;
      const link = resolveHeroLink(cfg, data);
      return (
        <Card className="p-6">
          {strConfig(cfg, "badge") && (
            <Badge variant="secondary" className="mb-2">
              {strConfig(cfg, "badge")}
            </Badge>
          )}
          {title && <h3 className="font-display text-lg font-semibold">{title}</h3>}
          {body && (
            <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{body}</p>
          )}
          {strConfig(cfg, "button_text") && (
            <div className="mt-4">
              <HeroButton link={link} label={strConfig(cfg, "button_text")} />
            </div>
          )}
        </Card>
      );
    }
    default:
      return null;
  }
}

export function useFeedHighlightRef() {
  return useRef<HTMLDivElement | null>(null);
}
