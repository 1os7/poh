import { AlertCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export function QueryError({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <Card className="p-8 text-center">
      <AlertCircle className="h-8 w-8 mx-auto text-destructive mb-3" />
      <p className="font-medium">Не удалось загрузить данные</p>
      <p className="mt-2 text-sm text-muted-foreground">{message}</p>
      {onRetry && (
        <Button variant="outline" className="mt-4" onClick={onRetry}>
          Повторить
        </Button>
      )}
    </Card>
  );
}
