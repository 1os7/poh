import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { DragOrderQuestion } from "@/components/test/DragOrderQuestion";
import type { AnswerValue, TestQuestion } from "@/lib/test-utils";

type Props = {
  question: TestQuestion;
  value: AnswerValue | undefined;
  onChange: (value: AnswerValue) => void;
  /** Для drag_drop — перемешанный порядок при первом показе */
  shuffledOptionIds?: string[];
};

export function QuestionPrompt({ question, value, onChange, shuffledOptionIds }: Props) {
  const q = question;

  if (q.question_type === "single" || q.question_type === "true_false") {
    return (
      <RadioGroup value={(value as string) ?? ""} onValueChange={onChange}>
        {[...q.answer_options]
          .sort((a, b) => a.position - b.position)
          .map((o) => (
            <Label
              key={o.id}
              htmlFor={o.id}
              className="flex items-center gap-3 rounded-lg border border-border p-3 cursor-pointer hover:bg-accent transition"
            >
              <RadioGroupItem value={o.id} id={o.id} />
              <span className="font-normal">{o.answer_text}</span>
            </Label>
          ))}
      </RadioGroup>
    );
  }

  if (q.question_type === "multiple") {
    const selected = (value as string[]) ?? [];
    return (
      <>
        {q.answer_options.map((o) => {
          const checked = selected.includes(o.id);
          return (
            <Label
              key={o.id}
              className="flex items-center gap-3 rounded-lg border border-border p-3 cursor-pointer hover:bg-accent transition"
            >
              <Checkbox
                checked={checked}
                onCheckedChange={(c) =>
                  onChange(
                    c ? [...selected, o.id] : selected.filter((x) => x !== o.id),
                  )
                }
              />
              <span className="font-normal">{o.answer_text}</span>
            </Label>
          );
        })}
      </>
    );
  }

  if (q.question_type === "text") {
    return (
      <textarea
        className="w-full min-h-32 rounded-lg border border-input bg-background p-3 text-sm"
        placeholder="Введите ответ…"
        value={(value as string) ?? ""}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  if (q.question_type === "drag_drop") {
    const opts = [...q.answer_options].sort((a, b) => a.position - b.position);
    const displayOpts = shuffledOptionIds
      ? shuffledOptionIds.map((id) => opts.find((o) => o.id === id)!).filter(Boolean)
      : opts;
    const order = (value as string[]) ?? [];
    return (
      <DragOrderQuestion
        options={displayOpts}
        order={order.length ? order : displayOpts.map((o) => o.id)}
        onChange={onChange}
      />
    );
  }

  return <p className="text-sm text-muted-foreground">Неподдерживаемый тип вопроса</p>;
}
