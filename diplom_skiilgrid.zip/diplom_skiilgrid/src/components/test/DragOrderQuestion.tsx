import { GripVertical } from "lucide-react";
import type { TestOption } from "@/lib/test-utils";

type Props = {
  options: TestOption[];
  order: string[];
  onChange: (order: string[]) => void;
};

export function DragOrderQuestion({ options, order, onChange }: Props) {
  const ordered =
    order.length === options.length
      ? order.map((id) => options.find((o) => o.id === id)!).filter(Boolean)
      : options;

  const move = (from: number, to: number) => {
    if (to < 0 || to >= ordered.length) return;
    const next = [...ordered];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    onChange(next.map((o) => o.id));
  };

  const onDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData("text/plain", String(index));
    e.dataTransfer.effectAllowed = "move";
  };

  const onDrop = (e: React.DragEvent, toIndex: number) => {
    e.preventDefault();
    const from = Number(e.dataTransfer.getData("text/plain"));
    if (!Number.isNaN(from)) move(from, toIndex);
  };

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground mb-2">
        Перетащите пункты в правильном порядке (сверху вниз)
      </p>
      {ordered.map((opt, index) => (
        <div
          key={opt.id}
          draggable
          onDragStart={(e) => onDragStart(e, index)}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => onDrop(e, index)}
          className="flex items-center gap-3 rounded-lg border border-border p-3 bg-card cursor-grab active:cursor-grabbing hover:bg-accent/50 transition"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground shrink-0" />
          <span className="text-xs font-medium text-muted-foreground w-5">{index + 1}.</span>
          <span className="flex-1 text-sm">{opt.answer_text}</span>
          <div className="flex flex-col gap-0.5">
            <button
              type="button"
              className="text-xs text-muted-foreground hover:text-foreground px-1"
              onClick={() => move(index, index - 1)}
              disabled={index === 0}
              aria-label="Выше"
            >
              ↑
            </button>
            <button
              type="button"
              className="text-xs text-muted-foreground hover:text-foreground px-1"
              onClick={() => move(index, index + 1)}
              disabled={index === ordered.length - 1}
              aria-label="Ниже"
            >
              ↓
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
