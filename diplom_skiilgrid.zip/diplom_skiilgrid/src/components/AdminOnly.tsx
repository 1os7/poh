import { Navigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export function AdminOnly({ children }: { children: React.ReactNode }) {
  const { loading, isAdmin, user } = useAuth();
  if (loading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" />;
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto text-center py-16">
        <h2 className="font-display text-xl font-semibold">Доступ только для администраторов</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Запросите права у владельца аккаунта или вернитесь в кабинет сотрудника.
        </p>
      </div>
    );
  }
  return <>{children}</>;
}
