import { useEffect, useState } from "react";
import { toast } from "sonner";
import { testsApi } from "@/lib/api";
import { QUESTION_TYPE_LABELS, type QuestionType } from "@/lib/test-utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2 } from "lucide-react";

export type OptionDraft = {
  answer_text: string;
  is_correct: boolean;
  position: number;
};

export type QuestionDraft = {
  id?: string;
  question_text: string;
  question_type: QuestionType;
  points: number;
  position: number;
  answer_options: OptionDraft[];
};

const emptyQuestion = (position: number): QuestionDraft => ({
  question_text: "",
  question_type: "single",
  points: 1,
  position,
  answer_options: [
    { answer_text: "", is_correct: true, position: 0 },
    { answer_text: "", is_correct: false, position: 1 },
  ],
});

type Props = {
  testId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initial?: QuestionDraft | null;
  nextPosition: number;
  onSaved: () => void;
};

export function QuestionFormDialog({
  testId,
  open,
  onOpenChange,
  initial,
  nextPosition,
  onSaved,
}: Props) {
  const [form, setForm] = useState<QuestionDraft>(emptyQuestion(nextPosition));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(
        initial
          ? {
              ...initial,
              answer_options: initial.answer_options.map((o, i) => ({ ...o, position: i })),
            }
          : emptyQuestion(nextPosition),
      );
    }
  }, [open, initial, nextPosition]);

  const setType = (type: QuestionType) => {
    if (type === "true_false") {
      setForm((f) => ({
        ...f,
        question_type: type,
        answer_options: [
          { answer_text: "Верно", is_correct: true, position: 0 },
          { answer_text: "Неверно", is_correct: false, position: 1 },
        ],
      }));
      return;
    }
    if (type === "text") {
      setForm((f) => ({
        ...f,
        question_type: type,
        answer_options: [{ answer_text: "", is_correct: true, position: 0 }],
      }));
      return;
    }
    if (type === "drag_drop") {
      setForm((f) => ({
        ...f,
        question_type: type,
        answer_options: [
          { answer_text: "Шаг 1", is_correct: false, position: 0 },
          { answer_text: "Шаг 2", is_correct: false, position: 1 },
          { answer_text: "Шаг 3", is_correct: false, position: 2 },
        ],
      }));
      return;
    }
    setForm((f) => ({ ...f, question_type: type }));
  };

  const addOption = () => {
    setForm((f) => ({
      ...f,
      answer_options: [
        ...f.answer_options,
        { answer_text: "", is_correct: false, position: f.answer_options.length },
      ],
    }));
  };

  const removeOption = (index: number) => {
    setForm((f) => ({
      ...f,
      answer_options: f.answer_options
        .filter((_, i) => i !== index)
        .map((o, i) => ({ ...o, position: i })),
    }));
  };

  const save = async () => {
    if (!form.question_text.trim()) {
      toast.error("Введите текст вопроса");
      return;
    }
    if (form.question_type !== "text" && form.answer_options.length < 2) {
      toast.error("Добавьте минимум 2 варианта");
      return;
    }
    if (form.question_type === "single" && !form.answer_options.some((o) => o.is_correct)) {
      toast.error("Отметьте правильный вариант");
      return;
    }
    if (form.question_type === "multiple" && !form.answer_options.some((o) => o.is_correct)) {
      toast.error("Отметьте хотя бы один правильный вариант");
      return;
    }
    if (form.question_type === "text" && !form.answer_options[0]?.answer_text.trim()) {
      toast.error("Укажите эталонный ответ");
      return;
    }

    const payload = {
      question_text: form.question_text,
      question_type: form.question_type,
      points: form.points,
      position: form.position,
      answer_options: form.answer_options.map((o, i) => ({
        answer_text: o.answer_text,
        is_correct: form.question_type === "drag_drop" ? false : o.is_correct,
        position: i,
      })),
    };

    setSaving(true);
    try {
      if (form.id) {
        await testsApi.updateQuestion(testId, form.id, payload);
        toast.success("Вопрос обновлён");
      } else {
        await testsApi.addQuestion(testId, payload);
        toast.success("Вопрос добавлен");
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Ошибка");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{form.id ? "Редактировать вопрос" : "Новый вопрос"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Текст вопроса</Label>
            <Textarea
              value={form.question_text}
              onChange={(e) => setForm({ ...form, question_text: e.target.value })}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Тип</Label>
              <Select value={form.question_type} onValueChange={(v) => setType(v as QuestionType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(QUESTION_TYPE_LABELS) as QuestionType[]).map((t) => (
                    <SelectItem key={t} value={t}>
                      {QUESTION_TYPE_LABELS[t]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Баллы</Label>
              <Input
                type="number"
                min={1}
                value={form.points}
                onChange={(e) => setForm({ ...form, points: Number(e.target.value) })}
              />
            </div>
          </div>

          {form.question_type === "text" ? (
            <div>
              <Label>Правильный ответ (точное совпадение, без учёта регистра)</Label>
              <Input
                value={form.answer_options[0]?.answer_text ?? ""}
                onChange={(e) =>
                  setForm({
                    ...form,
                    answer_options: [{ answer_text: e.target.value, is_correct: true, position: 0 }],
                  })
                }
              />
            </div>
          ) : form.question_type === "drag_drop" ? (
            <div className="space-y-2">
              <Label>Пункты в правильном порядке (сверху вниз)</Label>
              {form.answer_options.map((opt, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <span className="text-xs text-muted-foreground w-5">{i + 1}.</span>
                  <Input
                    value={opt.answer_text}
                    onChange={(e) => {
                      const next = [...form.answer_options];
                      next[i] = { ...next[i], answer_text: e.target.value };
                      setForm({ ...form, answer_options: next });
                    }}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeOption(i)}
                    disabled={form.answer_options.length <= 2}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={addOption} className="gap-1">
                <Plus className="h-4 w-4" /> Пункт
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>
                {form.question_type === "multiple"
                  ? "Варианты (отметьте все правильные)"
                  : "Варианты ответа (один правильный)"}
              </Label>
              {form.answer_options.map((opt, i) => (
                <div key={i} className="flex gap-2 items-center">
                  {(form.question_type === "single" || form.question_type === "multiple") && (
                    <Checkbox
                      checked={opt.is_correct}
                      onCheckedChange={(c) => {
                        const next = form.answer_options.map((o, j) => {
                          if (form.question_type === "single") {
                            return { ...o, is_correct: j === i && !!c };
                          }
                          return j === i ? { ...o, is_correct: !!c } : o;
                        });
                        setForm({ ...form, answer_options: next });
                      }}
                    />
                  )}
                  <Input
                    className="flex-1"
                    value={opt.answer_text}
                    onChange={(e) => {
                      const next = [...form.answer_options];
                      next[i] = { ...next[i], answer_text: e.target.value };
                      setForm({ ...form, answer_options: next });
                    }}
                    disabled={form.question_type === "true_false"}
                  />
                  {form.question_type !== "true_false" && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(i)}
                      disabled={form.answer_options.length <= 2}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              {form.question_type !== "true_false" && (
                <Button type="button" variant="outline" size="sm" onClick={addOption} className="gap-1">
                  <Plus className="h-4 w-4" /> Вариант
                </Button>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button onClick={save} disabled={saving}>
            {saving ? "Сохранение…" : "Сохранить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
