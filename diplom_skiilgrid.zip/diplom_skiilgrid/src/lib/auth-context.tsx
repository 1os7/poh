import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import {
  authApi,
  clearToken,
  getToken,
  setToken,
  type AppRole,
  type UserProfile,
} from "@/lib/api";

export type { AppRole, UserProfile };

interface AuthCtx {
  user: UserProfile | null;
  profile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  roles: AppRole[];
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, full_name?: string) => Promise<void>;
  signOut: () => void;
  refresh: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadMe = useCallback(async () => {
    try {
      const me = await authApi.me();
      setUser(me);
    } catch {
      clearToken();
      setUser(null);
    }
  }, []);

  useEffect(() => {
    if (getToken()) {
      loadMe().finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [loadMe]);

  const signIn = async (email: string, password: string) => {
    const { access_token, user: me } = await authApi.login({ email, password });
    setToken(access_token);
    setUser(me);
  };

  const signUp = async (email: string, password: string, full_name?: string) => {
    const { access_token, user: me } = await authApi.register({ email, password, full_name });
    setToken(access_token);
    setUser(me);
  };

  const signOut = () => {
    clearToken();
    setUser(null);
  };

  const refresh = async () => {
    await loadMe();
  };

  const roles: AppRole[] = user ? [user.role] : [];
  const isAdmin = user?.role === "admin";

  return (
    <Ctx.Provider
      value={{
        user,
        profile: user,
        loading,
        isAdmin,
        roles,
        signIn,
        signUp,
        signOut,
        refresh,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
