export type QuestionType = "single" | "multiple" | "text" | "true_false" | "drag_drop";

export type TestOption = {
  id: string;
  answer_text: string;
  is_correct: boolean;
  position: number;
};

export type TestQuestion = {
  id: string;
  question_text: string;
  question_type: QuestionType;
  points: number;
  position: number;
  answer_options: TestOption[];
};

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  single: "Один ответ",
  multiple: "Несколько ответов",
  text: "Текстовый ответ",
  true_false: "Верно / Неверно",
  drag_drop: "Расставить по порядку",
};

export type AnswerValue = string | string[];

export function hasAnswer(q: TestQuestion, answers: Record<string, AnswerValue>): boolean {
  const a = answers[q.id];
  if (q.question_type === "multiple" || q.question_type === "drag_drop") {
    return Array.isArray(a) && a.length > 0;
  }
  if (q.question_type === "text") {
    return typeof a === "string" && a.trim().length > 0;
  }
  return typeof a === "string" && a.length > 0;
}

/** Локальный предпросмотр балла (итог считает сервер). */
export function previewScore(
  questions: TestQuestion[],
  answers: Record<string, AnswerValue>,
  correctKey?: Map<string, TestQuestion>,
): number {
  if (!questions.length) return 0;
  let earned = 0;
  let total = 0;
  for (const q of questions) {
    total += q.points;
    const ref = correctKey?.get(q.id) ?? q;
    const a = answers[q.id];
    if (ref.question_type === "single" || ref.question_type === "true_false") {
      const correct = ref.answer_options.find((o) => o.is_correct)?.id;
      if (a === correct) earned += q.points;
    } else if (ref.question_type === "multiple") {
      const correct = ref.answer_options
        .filter((o) => o.is_correct)
        .map((o) => o.id)
        .sort();
      const given = Array.isArray(a) ? [...a].sort() : [];
      if (JSON.stringify(correct) === JSON.stringify(given)) earned += q.points;
    } else if (ref.question_type === "text") {
      const expected = ref.answer_options
        .find((o) => o.is_correct)
        ?.answer_text.trim()
        .toLowerCase();
      if (expected && typeof a === "string" && a.trim().toLowerCase() === expected) {
        earned += q.points;
      }
    } else if (ref.question_type === "drag_drop") {
      const correct = [...ref.answer_options]
        .sort((x, y) => x.position - y.position)
        .map((o) => o.id);
      const given = Array.isArray(a) ? a : [];
      if (JSON.stringify(correct) === JSON.stringify(given)) earned += q.points;
    }
  }
  return total > 0 ? (earned / total) * 100 : 0;
}

export function shuffleOptions<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
