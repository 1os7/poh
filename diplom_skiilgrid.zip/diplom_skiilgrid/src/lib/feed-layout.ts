export type FeedBlockType =
  | "hero"
  | "stats"
  | "announcements"
  | "continue_courses"
  | "new_courses"
  | "tests"
  | "recent_activity"
  | "custom";

export interface FeedBlock {
  id: string;
  type: FeedBlockType;
  enabled: boolean;
  config: Record<string, unknown>;
}

export interface FeedLayout {
  title_template: string;
  page_description: string | null;
  blocks: FeedBlock[];
  updated_at?: string;
}

export const BLOCK_LABELS: Record<FeedBlockType, string> = {
  hero: "Баннер (hero)",
  stats: "Статистика",
  announcements: "Объявления",
  continue_courses: "Продолжить обучение",
  new_courses: "Рекомендуемые курсы",
  tests: "Тесты",
  recent_activity: "Недавняя активность",
  custom: "Свой блок",
};

export function defaultBlockConfig(type: FeedBlockType): Record<string, unknown> {
  switch (type) {
    case "hero":
      return {
        badge: "Аттестация",
        title: "Проверьте компетенции",
        body: "Описание баннера",
        button_text: "Перейти",
        link_mode: "auto_test",
        test_id: "",
        course_id: "",
        url: "/tests",
      };
    case "stats":
      return {
        label_courses: "Курсов в работе",
        label_tests: "Тестов пройдено",
        label_passed: "Успешных попыток",
      };
    case "announcements":
      return { title: "Объявления" };
    case "continue_courses":
      return { title: "Продолжить обучение", max_items: 3 };
    case "new_courses":
      return { title: "Рекомендуемые курсы", max_items: 4 };
    case "tests":
      return { title: "Тесты к прохождению", max_items: 4 };
    case "recent_activity":
      return { title: "Недавняя активность", max_items: 5 };
    case "custom":
      return {
        badge: "",
        title: "Заголовок блока",
        body: "Текст блока",
        button_text: "",
        link_mode: "none",
        test_id: "",
        course_id: "",
        url: "",
      };
    default:
      return {};
  }
}

export function newFeedBlock(type: FeedBlockType): FeedBlock {
  return {
    id: `${type}-${Date.now()}`,
    type,
    enabled: true,
    config: defaultBlockConfig(type),
  };
}

export function strConfig(cfg: Record<string, unknown>, key: string, fallback = ""): string {
  const v = cfg[key];
  return typeof v === "string" ? v : fallback;
}

export function numConfig(cfg: Record<string, unknown>, key: string, fallback: number): number {
  const v = cfg[key];
  if (typeof v === "number" && !Number.isNaN(v)) return v;
  if (typeof v === "string" && v !== "") {
    const n = Number(v);
    if (!Number.isNaN(n)) return n;
  }
  return fallback;
}
