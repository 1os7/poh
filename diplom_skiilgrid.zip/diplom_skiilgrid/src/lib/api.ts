/**
 * Skillgrid API client — FastAPI backend at VITE_API_URL.
 */

/** В dev без VITE_API_URL запросы идут через Vite proxy (/api → :8000), без CORS. */
const BASE =
  import.meta.env.VITE_API_URL ??
  (import.meta.env.DEV ? "/api" : "http://localhost:8000");
const TOKEN_KEY = "skillgrid_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

function parseDetail(detail: unknown): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((item) => {
        if (typeof item === "object" && item && "msg" in item) {
          return String((item as { msg: string }).msg);
        }
        return String(item);
      })
      .join(", ");
  }
  return "Неизвестная ошибка";
}

async function request<T>(
  method: string,
  path: string,
  body?: unknown,
  auth = true,
): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error(
      "Не удалось подключиться к API. Запустите backend: cd backend && uvicorn main:app --reload --port 8000",
    );
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: "Ошибка сети" }));
    throw new Error(parseDetail(err.detail));
  }

  if (res.status === 204) return undefined as T;
  return res.json();
}

const api = {
  get: <T>(path: string, auth = true) => request<T>("GET", path, undefined, auth),
  post: <T>(path: string, body?: unknown, auth = true) => request<T>("POST", path, body, auth),
  patch: <T>(path: string, body?: unknown) => request<T>("PATCH", path, body),
  delete: <T>(path: string) => request<T>("DELETE", path),
};

export default api;

export type AppRole = "admin" | "employee";

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  department: string | null;
  position: string | null;
  role: AppRole;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface Course {
  id: string;
  title: string;
  description: string | null;
  category_id: string | null;
  cover_url: string | null;
  is_published: boolean;
  passing_score: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  lesson_count: number;
  enrolled: boolean;
  progress: number;
  final_test_id: string | null;
  final_test_title: string | null;
  lessons_completed: number;
  lessons_total: number;
  all_lessons_completed: boolean;
  can_take_final_test: boolean;
  final_test_passed: boolean;
  course_completed: boolean;
}

export interface Lesson {
  id: string;
  course_id: string;
  title: string;
  content: string | null;
  video_url: string | null;
  position: number;
  created_at: string;
  completed: boolean;
}

export interface Test {
  id: string;
  title: string;
  description: string | null;
  category_id: string | null;
  course_id: string | null;
  duration_minutes: number;
  passing_score: number;
  max_attempts: number;
  is_published: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  question_count?: number;
  user_passed?: boolean;
  user_best_score?: number | null;
  user_attempts?: number;
  user_attempts_left?: number | null;
  can_attempt?: boolean;
}

export interface AdminAnalytics {
  score_by_month: { month: string; avg_score: number; attempts: number }[];
  by_department: { name: string; attempts: number; share: number; pass_rate: number }[];
  activity_by_day: { name: string; count: number }[];
}

export interface AnswerOption {
  id: string;
  answer_text: string;
  is_correct: boolean;
  position: number;
}

export interface Question {
  id: string;
  question_text: string;
  question_type: "single" | "multiple" | "text" | "true_false" | "drag_drop";
  points: number;
  position: number;
  answer_options: AnswerOption[];
}

export interface TestWithQuestions extends Test {
  questions: Question[];
}

export interface TestAttempt {
  id: string;
  test_id: string;
  test_title: string | null;
  score: number | null;
  passed: boolean | null;
  started_at: string;
  completed_at: string | null;
}

export interface AdminStats {
  users: number;
  active_tests: number;
  active_courses: number;
  avg_score: number;
  pass_rate: number;
  total_attempts: number;
}

export interface AuditEntry {
  id: string;
  user_id: string | null;
  action: string;
  entity: string | null;
  entity_id: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export const authApi = {
  register: (data: { email: string; password: string; full_name?: string }) =>
    api.post<{ access_token: string; user: UserProfile }>("/auth/register", data, false),
  login: (data: { email: string; password: string }) =>
    api.post<{ access_token: string; user: UserProfile }>("/auth/login", data, false),
  me: () => api.get<UserProfile>("/auth/me"),
};

export const profileApi = {
  update: (data: { full_name?: string; department?: string; position?: string }) =>
    api.patch<UserProfile>("/profile", data),
};

export const categoriesApi = {
  list: () => api.get<Category[]>("/categories"),
  create: (data: { name: string; description?: string }) => api.post<Category>("/categories", data),
  delete: (id: string) => api.delete<void>(`/categories/${id}`),
};

export const coursesApi = {
  list: () => api.get<Course[]>("/courses"),
  get: (id: string) => api.get<Course>(`/courses/${id}`),
  create: (data: {
    title: string;
    description?: string;
    category_id?: string;
    cover_url?: string;
    passing_score?: number;
  }) => api.post<Course>("/courses", data),
  update: (
    id: string,
    data: Partial<{
      title: string;
      description: string;
      category_id: string;
      cover_url: string;
      is_published: boolean;
      passing_score: number;
    }>,
  ) => api.patch<Course>(`/courses/${id}`, data),
  delete: (id: string) => api.delete<void>(`/courses/${id}`),
  listLessons: (courseId: string) => api.get<Lesson[]>(`/courses/${courseId}/lessons`),
  createLesson: (
    courseId: string,
    data: { title: string; content?: string; video_url?: string; position?: number },
  ) => api.post<Lesson>(`/courses/${courseId}/lessons`, data),
  updateLesson: (
    courseId: string,
    lessonId: string,
    data: Partial<{ title: string; content: string; video_url: string; position: number }>,
  ) => api.patch<Lesson>(`/courses/${courseId}/lessons/${lessonId}`, data),
  deleteLesson: (courseId: string, lessonId: string) =>
    api.delete<void>(`/courses/${courseId}/lessons/${lessonId}`),
  enroll: (courseId: string) =>
    api.post<{ id: string; progress: number }>(`/courses/${courseId}/enroll`),
  completeLesson: (courseId: string, lessonId: string) =>
    api.post<{ completed: boolean }>(`/courses/${courseId}/lessons/${lessonId}/complete`),
  myCourses: () => api.get<Course[]>("/my/courses"),
};

export const testsApi = {
  list: () => api.get<Test[]>("/tests"),
  get: (id: string) => api.get<TestWithQuestions>(`/tests/${id}`),
  create: (data: {
    title: string;
    description?: string;
    category_id?: string;
    course_id?: string;
    duration_minutes?: number;
    passing_score?: number;
    max_attempts?: number;
  }) => api.post<Test>("/tests", data),
  update: (
    id: string,
    data: Partial<{
      title: string;
      description: string;
      category_id: string;
      course_id: string;
      duration_minutes: number;
      passing_score: number;
      max_attempts: number;
      is_published: boolean;
    }>,
  ) => api.patch<Test>(`/tests/${id}`, data),
  delete: (id: string) => api.delete<void>(`/tests/${id}`),
  addQuestion: (
    testId: string,
    data: {
      question_text: string;
      question_type: string;
      points?: number;
      position?: number;
      answer_options?: { answer_text: string; is_correct: boolean; position?: number }[];
    },
  ) => api.post<Question>(`/tests/${testId}/questions`, data),
  updateQuestion: (
    testId: string,
    questionId: string,
    data: Partial<Question & { answer_options: { answer_text: string; is_correct: boolean }[] }>,
  ) => api.patch<Question>(`/tests/${testId}/questions/${questionId}`, data),
  deleteQuestion: (testId: string, questionId: string) =>
    api.delete<void>(`/tests/${testId}/questions/${questionId}`),
  submitAttempt: (
    testId: string,
    data: { answers: Record<string, unknown>; score: number; passed: boolean },
  ) =>
    api.post<{
      id: string;
      score: number;
      passed: boolean;
      completed_at: string;
      course_id?: string | null;
    }>(`/tests/${testId}/attempts`, data),
  myAttempts: () => api.get<TestAttempt[]>("/my/attempts"),
};

export const adminApi = {
  stats: () => api.get<AdminStats>("/admin/stats"),
  analytics: () => api.get<AdminAnalytics>("/admin/analytics"),
  users: () => api.get<UserProfile[]>("/admin/users"),
  setRole: (userId: string, role: AppRole) =>
    api.patch<UserProfile>(`/admin/users/${userId}/role`, { role }),
  audit: () => api.get<AuditEntry[]>("/admin/audit"),
  seedDemo: () => api.post<{ seeded: boolean; message: string }>("/admin/seed-demo"),
  announcements: {
    list: () => api.get<Announcement[]>("/admin/announcements"),
    create: (data: { title: string; body: string; tag?: string }) =>
      api.post<Announcement>("/admin/announcements", data),
    update: (
      id: string,
      data: Partial<{ title: string; body: string; tag: string; is_published: boolean }>,
    ) => api.patch<Announcement>(`/admin/announcements/${id}`, data),
    delete: (id: string) => api.delete<void>(`/admin/announcements/${id}`),
    publish: (id: string) =>
      api.post<{ announcement: Announcement; notifications_sent: number }>(
        `/admin/announcements/${id}/publish`,
      ),
    notify: (id: string) =>
      api.post<{ notifications_sent: number }>(`/admin/announcements/${id}/notify`),
  },
  feedLayout: {
    get: () => api.get<FeedLayout>("/admin/feed/layout"),
    update: (data: Partial<Pick<FeedLayout, "title_template" | "page_description" | "blocks">>) =>
      api.put<FeedLayout>("/admin/feed/layout", data),
  },
};

export const notificationsApi = {
  list: (unreadOnly = false) =>
    api.get<UserNotification[]>(`/notifications${unreadOnly ? "?unread_only=true" : ""}`),
  unreadCount: () => api.get<{ count: number }>("/notifications/unread-count"),
  markRead: (id: string) => api.patch<UserNotification>(`/notifications/${id}/read`),
  markAllRead: () => api.post<{ marked: number }>("/notifications/read-all"),
};

export interface FeedHighlight {
  id: string;
  title: string;
  body: string;
  tag: string;
  is_published?: boolean;
  published_at?: string | null;
  is_read?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  tag: string;
  is_published: boolean;
  published_at: string | null;
  created_at: string;
  updated_at: string;
  is_read?: boolean;
}

export interface UserNotification {
  id: string;
  title: string;
  body: string;
  tag: string | null;
  announcement_id: string | null;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
}

export interface FeedData {
  layout: FeedLayout;
  greeting: string;
  continue_courses: Course[];
  new_courses: Course[];
  tests_due: Test[];
  featured_test_id: string | null;
  featured_test_title: string | null;
  recent_attempts: TestAttempt[];
  stats: {
    courses_enrolled: number;
    tests_completed: number;
    tests_passed: number;
  };
  highlights: FeedHighlight[];
}

export interface FeedLayout {
  title_template: string;
  page_description: string | null;
  blocks: FeedBlock[];
  updated_at?: string;
}

export interface FeedBlock {
  id: string;
  type: string;
  enabled: boolean;
  config: Record<string, unknown>;
}

export const feedApi = {
  get: () => api.get<FeedData>("/feed"),
};
