# Skillgrid

Корпоративная платформа оценки компетенций: курсы, тесты, аналитика.

## Стек

- **Frontend:** React 19, TanStack Start/Router, Tailwind CSS 4
- **Backend:** FastAPI, SQLAlchemy, SQLite, JWT

## Запуск

### 1. API (терминал 1)

```bash
cd backend
source .venv/bin/activate
uvicorn main:app --reload --port 8000
```

Перезапустите API после обновления — подтянутся демо-данные и исправится email админа.

### 2. Frontend (терминал 2)

```bash
npm install
npm run dev
```

Откройте http://localhost:5173

## Учётные записи (демо)

| Роль        | Email               | Пароль     |
|-------------|---------------------|------------|
| Администратор | `admin@skillgrid.ru` | `Admin1234` |
| Сотрудник   | `demo@skillgrid.ru`  | `Demo1234`  |

После входа открывается **Лента** (`/feed`) — главная страница с курсами, тестами и активностью. **Мой кабинет** (`/dashboard`) — личная статистика.

Если демо-контента нет: войдите как админ и вызовите `POST /admin/seed-demo` или перезапустите API на пустой БД.
